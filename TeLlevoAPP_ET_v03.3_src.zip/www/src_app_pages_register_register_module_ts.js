"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_register_register_module_ts"],{

/***/ 1557:
/*!***********************************************************!*\
  !*** ./src/app/pages/register/register-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 6690);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 207:
/*!***************************************************!*\
  !*** ./src/app/pages/register/register.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 1557);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 6690);







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 6690:
/*!*************************************************!*\
  !*** ./src/app/pages/register/register.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.html?ngResource */ 6325);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 7863);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_enums_register_status__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/enums/register-status */ 9394);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/storage.service */ 1188);










let RegisterPage = class RegisterPage {
  constructor(_modalCtrl, _router, _storage, _toastCtrl, _auth) {
    this._modalCtrl = _modalCtrl;
    this._router = _router;
    this._storage = _storage;
    this._toastCtrl = _toastCtrl;
    this._auth = _auth;
    this.credenciales = {
      correo: '',
      rawExtension: '',
      extension: '',
      rut: '',
      nombre: '',
      contrasena: '',
      contrasena2: '',
      conductor: false,
      patente: '',
      condiciones: false,
      codigo: ''
    };
  }

  ngOnInit() {}

  conductorChange() {
    //this.credenciales.conductor ? document.getElementsByClassName('patenteInput')[0].setAttribute("style", "display: flex;") : document.getElementsByClassName('patenteInput')[0].setAttribute("style", "display: none;");
    if (this.credenciales.conductor) {
      document.getElementsByClassName('patenteInput')[0].setAttribute("style", "display: flex; flex-direction: column;");
      document.getElementsByClassName('patenteInput')[0].setAttribute("required", ""); //this.registerform.form.get('patente').setValidators([Validators.required]);
      //this.registerform.form.get('patente').updateValueAndValidity();
    } else {
      document.getElementsByClassName('patenteInput')[0].setAttribute("style", "display: none;");
      document.getElementsByClassName('patenteInput')[0].removeAttribute("required"); //this.registerform.form.get('patente').clearValidators();
      //this.registerform.form.get('patente').updateValueAndValidity();
    }
  }

  checkPasswords() {
    if (this.credenciales.contrasena != '' && this.credenciales.contrasena2 != '') {
      if (this.credenciales.contrasena != '' && this.credenciales.contrasena2 != '') {
        if (this.credenciales.contrasena != this.credenciales.contrasena2) {
          this.registerform.form.controls['contrasena2'].setErrors({
            'incorrect': true
          });
          return false;
        } else {
          this.registerform.form.controls['contrasena2'].setErrors(null);
          return true;
        }
      }
    }

    return true;
  }

  lastStepRegistration() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this._toastCtrl.create({
        icon: 'close-circle-outline',
        duration: 3000,
        buttons: [{
          text: 'Cerrar',
          role: 'cerrar',
          icon: 'close-circle-outline',
          handler: () => {
            toast.dismiss('ok');
          }
        }]
      });
      _this.credenciales.extension = _this.credenciales.rawExtension == 'alumno' ? '@duocuc.cl' : '@profesor.duoc.cl';

      if (!_this._auth.userDoesExists(_this.credenciales.correo + _this.credenciales.extension)) {
        if (!_this._auth.rutDoesExists(_this.credenciales.rut)) {
          _this.codigo = Math.random().toString(36).substring(2, 9).toUpperCase();
          console.log('Este es el código. Pero prueba ir a tu correo <3 ' + _this.codigo);
          yield _this._auth.verifyMail(_this.credenciales.correo + _this.credenciales.extension, _this.codigo, _this.credenciales.nombre);
        } else {
          toast.message = '¡Error! Ya existe un usuario con ese rut';
          yield toast.present();
          yield _this._modalCtrl.dismiss('modal', 'cancelar');
        }
      } else {
        toast.message = '¡Error! Ya existe un usuario con ese correo';
        yield toast.present();
        yield _this._modalCtrl.dismiss('modal', 'cancelar');
      }
    })();
  }

  register() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.codigo == _this2.credenciales.codigo) {
        let wasRegistered = yield _this2._auth.registerUser(_this2.credenciales);

        if (wasRegistered === src_app_enums_register_status__WEBPACK_IMPORTED_MODULE_3__.RegisterStatus.SUCCESSFUL) {
          yield _this2._modalCtrl.dismiss('modal');
          const toast = yield _this2._toastCtrl.create({
            message: '¡Bienvenido a bordo!',
            icon: 'happy-outline',
            duration: 3000,
            buttons: [{
              text: 'Ver tu Perfil',
              role: 'perfil',
              icon: 'person-circle-outline',
              handler: () => {
                toast.dismiss('ok');

                _this2._modalCtrl.dismiss('modal', 'cancelar');

                _this2._router.navigate(['perfil']);
              }
            }]
          });
          yield toast.present();
        } else {
          yield _this2._modalCtrl.dismiss('modal', 'cancelar');
          const toast = yield _this2._toastCtrl.create({
            icon: 'close-circle-outline',
            duration: 3000,
            buttons: [{
              text: 'Cerrar',
              role: 'cerrar',
              icon: 'close-circle-outline',
              handler: () => {
                toast.dismiss('ok');
              }
            }]
          });

          if (wasRegistered === src_app_enums_register_status__WEBPACK_IMPORTED_MODULE_3__.RegisterStatus.ALREADY_REGISTERED) {
            toast.message = '¡Error! Ya existe un usuario con ese correo';
          } else if (wasRegistered === src_app_enums_register_status__WEBPACK_IMPORTED_MODULE_3__.RegisterStatus.RUT_ALREADY_EXISTS) {
            toast.message = '¡Error! Ya existe un usuario con ese rut';
          } else {
            toast.message = '¡Error! No se pudo registrar el usuario';
          }

          yield toast.present();
        }
      }
    })();
  }

  formatString(type) {
    if (type === 'rut') {
      const idealPattern = /[0-9]{2}\.[0-9]{3}\.[0-9]-([0-9]|k)/;
      const acceptablePattern = /[0-9]{2}(\.?)[0-9]{3}(\.?)[0-9]{3}(\.?)(-?)[0-9k]/;
      if (idealPattern.test(this.credenciales.rut)) return;

      if (acceptablePattern.test(this.credenciales.rut)) {
        const newRut = this.credenciales.rut.replace('-', '');
        let rut = newRut.substring(0, newRut.length - 1).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        let dv = newRut.substring(newRut.length - 1);
        this.credenciales.rut = rut + '-' + dv;
      }
    } else if (type === 'patente') {
      const idealPattern = /^[a-zA-Z]{2}-[a-zA-Z0-9]{2}-[a-zA-Z0-9]{2}$/;
      const acceptablePattern = /^[a-zA-Z]{2}(-?)[a-zA-Z0-9]{2}(-?)[a-zA-Z0-9]{2}$/;
      if (idealPattern.test(this.credenciales.patente)) return;

      if (acceptablePattern.test(this.credenciales.patente)) {
        this.credenciales.patente = this.credenciales.patente.match(/[a-zA-Z0-9]{2}/g).join("-").toUpperCase();
      }
    }
  }

  modalActions(type) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (type.toLowerCase() == 'close') {
        yield _this3._modalCtrl.dismiss('modal', 'cancelar');
      }
    })();
  }

};

RegisterPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService
}];

RegisterPage.propDecorators = {
  registerform: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['registerform']
  }]
};
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-register',
  template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], RegisterPage);


/***/ }),

/***/ 7863:
/*!**************************************************************!*\
  !*** ./src/app/pages/register/register.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = ".page-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.page-body:nth-child(1) {\n  font-size: 4vh;\n  font-weight: 600;\n  margin-top: 2vh;\n}\n\n.registrarse {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n  margin-top: 4vh;\n}\n\n.correo-input {\n  display: flex;\n  flex-direction: row;\n}\n\n.patenteInput {\n  display: none;\n}\n\n.crear-cuenta {\n  align-self: center;\n  justify-self: center;\n  --background: #8BEA7B;\n  --color: #000000;\n  --border-radius: 2vh;\n  font-size: 2vh;\n  font-weight: 600;\n  margin-top: 4vh;\n}\n\n.formControl-errormsg {\n  color: red;\n  font-size: 2vh;\n}\n\n.formControl-erroricon {\n  align-self: center;\n  justify-self: center;\n  width: 2vh;\n  height: 2vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxVQUFBO0VBQ0EsY0FBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7RUFDQSxvQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBQ0oiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBhZ2UtYm9keSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5wYWdlLWJvZHk6bnRoLWNoaWxkKDEpIHtcbiAgICBmb250LXNpemU6IDR2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIG1hcmdpbi10b3A6IDJ2aDtcbn1cblxuLnJlZ2lzdHJhcnNlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogNHZoO1xufVxuXG4uY29ycmVvLWlucHV0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG59XG5cbi5wYXRlbnRlSW5wdXQge1xuICAgIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5jcmVhci1jdWVudGEge1xuICAgIGFsaWduLXNlbGY6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LXNlbGY6IGNlbnRlcjtcbiAgICAtLWJhY2tncm91bmQ6ICM4QkVBN0I7XG4gICAgLS1jb2xvcjogIzAwMDAwMDtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDJ2aDtcbiAgICBmb250LXNpemU6IDJ2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIG1hcmdpbi10b3A6IDR2aDtcbn1cblxuLmZvcm1Db250cm9sLWVycm9ybXNnIHtcbiAgICBjb2xvcjogcmVkO1xuICAgIGZvbnQtc2l6ZTogMnZoO1xufVxuXG4uZm9ybUNvbnRyb2wtZXJyb3JpY29uIHtcbiAgICBhbGlnbi1zZWxmOiBjZW50ZXI7XG4gICAganVzdGlmeS1zZWxmOiBjZW50ZXI7XG4gICAgd2lkdGg6IDJ2aDtcbiAgICBoZWlnaHQ6IDJ2aDtcbn0iXX0= */";

/***/ }),

/***/ 6325:
/*!**************************************************************!*\
  !*** ./src/app/pages/register/register.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" default-href=\"/login\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"page-body\">\n    <span>Registro de Usuario</span>\n    <form name=\"registerform\" #registerform=\"ngForm\" (ngSubmit)=\"onSubmit()\" class=\"registrarse\">\n      <ion-item>\n        <ion-label position=\"stacked\">Correo Institucional</ion-label>\n        <div class=\"correo-input\">\n          <ion-input style=\"max-width: 50%;\" required name=\"correo\" clear-input mode=\"ios\" [(ngModel)]=\"credenciales.correo\"\n            placeholder=\"je.conuel\" pattern=\"^([a-zA-Z]+)\\.([a-zA-Z]+)[^@]\"></ion-input>\n          <ion-list>\n            <ion-item>\n              <ion-select required interface=\"popover\" placeholder=\"¿Alumno o Profesor?\" #extensioncorreo=\"ngModel\" [(ngModel)]=\"credenciales.rawExtension\" name=\"extensioncorreo\">\n                <ion-select-option value=\"alumno\">@duocuc.cl</ion-select-option>\n                <ion-select-option value=\"profesor\">@profesor.duoc.cl</ion-select-option>\n              </ion-select>\n            </ion-item>\n          </ion-list>\n        </div>\n        <ion-note *ngIf=\"credenciales.correo\" slot=\"error\">Correo inválido. Utiliza uno institucional</ion-note>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">RUT</ion-label>\n        <ion-input #rut=\"ngModel\" [(ngModel)]=\"credenciales.rut\" type=\"text\"\n          pattern=\"(([0-9]{1,2})\\.([0-9]{3})\\.([0-9]{3})-([0-9]|k)|([0-9]{8}[0-9|k]{1}))\" required name=\"rut\" clear-input mode=\"ios\"\n          placeholder=\"20.919.721-9\" (ionBlur)=\"formatString('rut')\"></ion-input>\n        <ion-note *ngIf=\"credenciales.rut\" slot=\"error\">RUT inválido</ion-note>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Nombre Completo</ion-label>\n        <ion-input #nombre=\"ngModel\" [(ngModel)]=\"credenciales.nombre\" type=\"text\" name=\"nombre\" mode=\"ios\" required\n          clear-input pattern=\"([a-zA-ZñÑÀ-ÖØ-öø-ÿ ]+)\"></ion-input>\n        <ion-note *ngIf=\"credenciales.nombre\" slot=\"error\">No ingreses símbolos en tu nombre</ion-note>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Contraseña</ion-label>\n        <ion-input (ionChange)=\"checkPasswords()\" #contrasena=\"ngModel\" [(ngModel)]=\"credenciales.contrasena\" type=\"password\" name=\"contrasena\"\n          mode=\"ios\" required clear-input></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label position=\"floating\">Confirmar Contraseña</ion-label>\n        <ion-input (ionChange)=\"checkPasswords()\" type=\"password\" name=\"contrasena2\" #contrasena2=\"ngModel\" [(ngModel)]=\"credenciales.contrasena2\"\n          mode=\"ios\" required clear-input></ion-input>\n        <ion-note *ngIf=\"!checkPasswords()\" slot=\"error\">Las contraseñas no coinciden</ion-note>\n      </ion-item>\n      <ion-item>\n        <ion-checkbox (ionChange)=\"conductorChange()\" slot=\"start\" [(ngModel)]=\"credenciales.conductor\"\n          name=\"conductor\"></ion-checkbox>\n        <ion-label>¿Eres conductor?</ion-label>\n      </ion-item>\n      <ion-item class=\"patenteInput\">\n        <ion-label position=\"floating\">Patente</ion-label>\n        <ion-input (ionBlur)=\"formatString('patente')\" #patente=\"ngModel\" [(ngModel)]=\"credenciales.patente\" type=\"text\" name=\"patente\" mode=\"ios\"\n          clear-input pattern=\"([a-zA-ZñÑ]{2})-(([a-zA-ZñÑ]|[0-9]){2})-([0-9]{2})\" placeholder=\"aa-bb-12\"></ion-input>\n        <ion-note *ngIf=\"credenciales.patente\" slot=\"error\">Patente inválida</ion-note>\n      </ion-item>\n      <ion-item>\n        <ion-checkbox required slot=\"start\" #condiciones=\"ngModel\" [(ngModel)]=\"credenciales.condiciones\"\n          name=\"condiciones\"></ion-checkbox>\n        <ion-label><a>¿Aceptas los términos y condiciones?</a></ion-label>\n        <ion-note *ngIf=\"!credenciales.condiciones\" slot=\"helper\" style=\"color: var(--highlight-color-invalid) !important;\">Debes aceptar los términos y condiciones.</ion-note>\n      </ion-item>\n      <ion-button id=\"open-modal\" expand=\"block\" class=\"ion-margin-top crear-cuenta\" (click)=\"lastStepRegistration()\" [disabled]=\"registerform.invalid || !condiciones.value\">\n        Crear Cuenta\n      </ion-button>\n      <!-- Modal -->\n      <ion-modal trigger=\"open-modal\" #modal name=\"modal\" id=\"modal\">\n        <ng-template>\n          <ion-header>\n            <ion-toolbar>\n              <ion-buttons slot=\"start\">\n                <ion-button (click)=\"modalActions('close')\">Cancelar</ion-button>\n              </ion-buttons>\n              <ion-title>Completar Registro</ion-title>\n            </ion-toolbar>\n          </ion-header>\n          <ion-content class=\"ion-padding\">\n            <ion-item>\n              <p>Se ha enviado un código al correo {{credenciales.correo}}{{credenciales.extension}}</p>\n              <ion-label position=\"stacked\">Ingresa el Código</ion-label>\n              <ion-input type=\"text\" placeholder=\"XXXXXX\" #inputcodigo=\"ngModel\" [(ngModel)]=\"credenciales.codigo\" name=\"inputcodigo\"></ion-input>\n            </ion-item>\n            <ion-button (click)=\"register()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n              Confirmar\n            </ion-button>\n          </ion-content>\n        </ng-template>\n      </ion-modal>\n      <!-- Fin Modal -->\n    </form>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_register_register_module_ts.js.map