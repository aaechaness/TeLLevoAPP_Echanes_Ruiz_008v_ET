"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_perfil-usuario_perfil-usuario_module_ts"],{

/***/ 6195:
/*!***********************************************************************!*\
  !*** ./src/app/pages/perfil-usuario/perfil-usuario-routing.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilUsuarioPageRoutingModule": () => (/* binding */ PerfilUsuarioPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _perfil_usuario_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil-usuario.page */ 4423);




const routes = [
    {
        path: '',
        component: _perfil_usuario_page__WEBPACK_IMPORTED_MODULE_0__.PerfilUsuarioPage
    }
];
let PerfilUsuarioPageRoutingModule = class PerfilUsuarioPageRoutingModule {
};
PerfilUsuarioPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PerfilUsuarioPageRoutingModule);



/***/ }),

/***/ 1712:
/*!***************************************************************!*\
  !*** ./src/app/pages/perfil-usuario/perfil-usuario.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilUsuarioPageModule": () => (/* binding */ PerfilUsuarioPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _perfil_usuario_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil-usuario-routing.module */ 6195);
/* harmony import */ var _perfil_usuario_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil-usuario.page */ 4423);







let PerfilUsuarioPageModule = class PerfilUsuarioPageModule {
};
PerfilUsuarioPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _perfil_usuario_routing_module__WEBPACK_IMPORTED_MODULE_0__.PerfilUsuarioPageRoutingModule
        ],
        declarations: [_perfil_usuario_page__WEBPACK_IMPORTED_MODULE_1__.PerfilUsuarioPage]
    })
], PerfilUsuarioPageModule);



/***/ }),

/***/ 4423:
/*!*************************************************************!*\
  !*** ./src/app/pages/perfil-usuario/perfil-usuario.page.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilUsuarioPage": () => (/* binding */ PerfilUsuarioPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _perfil_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil-usuario.page.html?ngResource */ 279);
/* harmony import */ var _perfil_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./perfil-usuario.page.scss?ngResource */ 9080);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);








let PerfilUsuarioPage = class PerfilUsuarioPage {
  constructor(_modalCtrl, _router, _alertCtrl, _toastCtrl, _auth) {
    this._modalCtrl = _modalCtrl;
    this._router = _router;
    this._alertCtrl = _alertCtrl;
    this._toastCtrl = _toastCtrl;
    this._auth = _auth;
    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.changes = {
      numero: null,
      codigo: null,
      password: '',
      password2: ''
    };
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.usuario = yield _this._auth.getSession();
      console.log(_this.usuario);
    })();
  }

  changeDriverStatus() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this2.usuario.patente != '') {
        _this2.usuario.patente = '';

        _this2._auth.updateUser(_this2.usuario);

        const alert = yield _this2._alertCtrl.create({
          header: '¡Hasta pronto!',
          subHeader: 'Dejaste de ser Conductor',
          message: 'Decidiste dejar de ser conductor, lamentamos esa decisión, pero esperamos que vuelvas pronto. Presiona "OK" para continuar.',
          mode: 'ios',
          buttons: [{
            text: 'OK',
            role: 'confirm',
            handler: () => {
              alert.dismiss();

              _this2.closeModal();

              _this2._router.navigate(['/perfil']);
            }
          }]
        });
        yield alert.present();
      } else {
        const alert = yield _this2._alertCtrl.create({
          header: '¡Sólo queda un paso!',
          message: 'Para ser conductor, debes ingresar la patente de tu medio de transporte (incluyendo guiones). Presiona "OK" para continuar una vez lo hayas hecho. Por otro lado, preciona "cancelar" para volver al perfil.',
          mode: 'ios',
          buttons: [{
            text: 'Cancelar',
            role: 'cancel',
            handler: () => {
              alert.dismiss();

              _this2._router.navigate(['/perfil']);
            }
          }, {
            text: 'OK',
            role: 'confirm',
            handler: alertData => {
              alert.dismiss();

              if (_this2.checkPatenteFormat(alertData.patente)) {
                if (/([a-zA-ZñÑ]{2})-(([a-zA-ZñÑ]|[0-9]){2})-([0-9]{2})/.test(alertData.patente)) {
                  _this2.usuario.patente = alertData.patente;
                } else {
                  _this2.usuario.patente = _this2.formatPatente(alertData.patente);
                }

                _this2._auth.updateUser(_this2.usuario);

                _this2.sendToast('¡Bienvenido a bordo! Ahora eres conductor de TeLlevoApp.');

                _this2.closeModal();

                _this2._router.navigate(['/perfil']);
              } else {
                _this2.sendToast('Ha ocurrido un error procesando la patente.');
              }
            }
          }],
          inputs: [{
            name: 'patente',
            type: 'text',
            placeholder: 'AA-BB-11',
            attributes: {
              maxlength: 8
            }
          }]
        });
        yield alert.present();
      }
    })();
  }

  checkPatenteFormat(patente) {
    let formato = /([a-zA-ZñÑ]{2})-(([a-zA-ZñÑ]|[0-9]){2})-([0-9]{2})/;

    if (formato.test(patente)) {
      return true;
    } else {
      let newPatente = this.formatPatente(patente);

      if (formato.test(newPatente)) {
        return true;
      } else {
        return false;
      }
    }
  }

  saveData(whatWasDeleted) {
    if (whatWasDeleted) {
      if (whatWasDeleted == 'numero') {
        this.usuario.numero = null;
      } else if (whatWasDeleted == 'foto') {
        this.usuario.foto = '';
      }
    } else {
      if (this.changes.numero != null && this.changes.numero != this.usuario.numero) {
        this.usuario.numero = this.changes.numero;
      }

      if (this.changes.password != '' && this.changes.password != null) {
        if (this.changes.password == this.changes.password2) {
          this._auth.changePassword(this.usuario, this.changes.password);
        } else {
          this.sendToast('Las contraseñas no coinciden.');
        }
      }
    } // Photo


    this._auth.updateUser(this.usuario);

    this.closeModal();

    this._router.navigate(['/perfil']);
  }

  changeImage(e) {
    let foto = e.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(foto);

    reader.onload = () => {
      this.usuario.foto = reader.result.toString();

      this._auth.updateUser(this.usuario);
    };

    reader.onerror = function (error) {
      console.log('Error: ', error);
    };
  }

  formatPatente(patente) {
    //let newPatente = patente.replace(/\B(?=([a-zA-ZñÑ0-9]{2})+(?!\d))/g, "-");
    return patente.match(/[a-zA-Z0-9]{2}/g).join("-");
  }

  sendToast(msg) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this3._toastCtrl.create({
        message: msg,
        duration: 3000
      });
      yield toast.present();
    })();
  }

  closeModal() {
    this._modalCtrl.getTop().then(modal => modal.dismiss());
  }

  logout() {
    this._auth.logout();
  }

};

PerfilUsuarioPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}];

PerfilUsuarioPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-perfil-usuario',
  template: _perfil_usuario_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_perfil_usuario_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], PerfilUsuarioPage);


/***/ }),

/***/ 9080:
/*!**************************************************************************!*\
  !*** ./src/app/pages/perfil-usuario/perfil-usuario.page.scss?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = ".contenido {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.contenido img {\n  width: 18vh;\n  height: 18vh;\n  border-radius: 10vh;\n  border: 1.5px solid black;\n}\n\n.informacion-personal {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n  margin-top: 4vh;\n  padding: 2vh;\n  border: 1px solid rgba(158, 158, 158, 0.8);\n  background-color: rgb(233, 232, 232);\n  filter: drop-shadow(-10px 0px 10px #B2B2B2);\n  width: 80%;\n}\n\n.info-block {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n}\n\n.info-perso-label {\n  font-size: 2vh;\n  font-weight: 600;\n  border-bottom: 1px black solid;\n}\n\n.info-perso-value {\n  font-size: 2.5vh;\n  font-weight: 400;\n  font-style: italic;\n  margin-top: 1vh;\n  margin-bottom: 2vh;\n}\n\n.editar-perfil {\n  display: flex;\n  align-self: center;\n  justify-self: center;\n  background-color: #8BEA7B;\n  color: black;\n  border-radius: 2vh;\n}\n\n#file-input::-webkit-file-upload-button {\n  visibility: hidden;\n}\n\n#file-input {\n  color: transparent;\n}\n\n#file-input::before {\n  margin-top: 1vh;\n  content: \"Seleccionar fotos\";\n  color: black;\n  display: inline-block;\n  background: -webkit-linear-gradient(top, #f9f9f9, #e3e3e3);\n  border: 1px solid #999;\n  border-radius: 3px;\n  padding: 5px 8px;\n  outline: none;\n  white-space: nowrap;\n  -webkit-user-select: none;\n  cursor: pointer;\n  text-shadow: 1px 1px #fff;\n  font-weight: 700;\n  font-size: 10pt;\n}\n\n.foto-perfil {\n  width: 12vh;\n  height: 12vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcmZpbC11c3VhcmlvLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFDSjs7QUFFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsMENBQUE7RUFDQSxvQ0FBQTtFQUNBLDJDQUFBO0VBQ0EsVUFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7QUFDSjs7QUFFQTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0VBQ0Esb0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksa0JBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSwwREFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6InBlcmZpbC11c3VhcmlvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250ZW5pZG8ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uY29udGVuaWRvIGltZyB7XG4gICAgd2lkdGg6IDE4dmg7XG4gICAgaGVpZ2h0OiAxOHZoO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwdmg7XG4gICAgYm9yZGVyOiAxLjVweCBzb2xpZCBibGFjaztcbn1cblxuLmluZm9ybWFjaW9uLXBlcnNvbmFsIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogNHZoO1xuICAgIHBhZGRpbmc6IDJ2aDtcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDE1OCwgMTU4LCAxNTgsIDAuOCk7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDIzMyAyMzIgMjMyKTtcbiAgICBmaWx0ZXI6IGRyb3Atc2hhZG93KC0xMHB4IDBweCAxMHB4ICNCMkIyQjIpO1xuICAgIHdpZHRoOiA4MCU7XG59XG5cbi5pbmZvLWJsb2NrIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi5pbmZvLXBlcnNvLWxhYmVsIHtcbiAgICBmb250LXNpemU6IDJ2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGJvcmRlci1ib3R0b206IDFweCBibGFjayBzb2xpZDtcbn1cblxuLmluZm8tcGVyc28tdmFsdWUge1xuICAgIGZvbnQtc2l6ZTogMi41dmg7XG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG4gICAgbWFyZ2luLXRvcDogMXZoO1xuICAgIG1hcmdpbi1ib3R0b206IDJ2aDtcbn1cblxuLmVkaXRhci1wZXJmaWwge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24tc2VsZjogY2VudGVyO1xuICAgIGp1c3RpZnktc2VsZjogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICM4QkVBN0I7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIGJvcmRlci1yYWRpdXM6IDJ2aDtcbn1cblxuI2ZpbGUtaW5wdXQ6Oi13ZWJraXQtZmlsZS11cGxvYWQtYnV0dG9uIHtcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG59XG5cbiNmaWxlLWlucHV0IHtcbiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7XG59XG5cbiNmaWxlLWlucHV0OjpiZWZvcmUge1xuICAgIG1hcmdpbi10b3A6IDF2aDtcbiAgICBjb250ZW50OiAnU2VsZWNjaW9uYXIgZm90b3MnO1xuICAgIGNvbG9yOiBibGFjaztcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgYmFja2dyb3VuZDogLXdlYmtpdC1saW5lYXItZ3JhZGllbnQodG9wLCAjZjlmOWY5LCAjZTNlM2UzKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjOTk5O1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICBwYWRkaW5nOiA1cHggOHB4O1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB0ZXh0LXNoYWRvdzogMXB4IDFweCAjZmZmO1xuICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgZm9udC1zaXplOiAxMHB0O1xufVxuXG4uZm90by1wZXJmaWwge1xuICAgIHdpZHRoOiAxMnZoO1xuICAgIGhlaWdodDogMTJ2aDtcbn0iXX0= */";

/***/ }),

/***/ 279:
/*!**************************************************************************!*\
  !*** ./src/app/pages/perfil-usuario/perfil-usuario.page.html?ngResource ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button (click)=\"_router.navigate(['home'])\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Perfil</ion-title>\n    <ion-icon slot=\"end\" (click)=\"_auth.logout()\" class=\"ion-padding\" size=\"large\" name=\"log-out-outline\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n<!-- Contenido -->\n<ion-content class=\"ion-padding\">\n  <div class=\"contenido\">\n    <img src=\"{{usuario.foto}}\" *ngIf=\"usuario.foto != ''; else noFoto\">\n    <ng-template #noFoto>\n      <img src=\"../../../assets/hellokitty.png\">\n    </ng-template>\n    <div class=\"informacion-personal\">\n      <section class=\"info-block\">\n        <span class=\"info-perso-label\">Nombre Completo</span>\n        <span class=\"info-perso-value\">{{usuario.nombre}}</span>\n      </section>\n      <section class=\"info-block\">\n        <span class=\"info-perso-label\">Rut</span>\n        <span class=\"info-perso-value\">{{usuario.rut}}</span>\n      </section>\n      <section class=\"info-block\">\n        <span class=\"info-perso-label\">Correo</span>\n        <span class=\"info-perso-value\">{{usuario.correo}}</span>\n      </section>\n      <section class=\"info-block\" *ngIf=\"usuario.numero != null\">\n        <span class=\"info-perso-label\">Teléfono</span>\n        <span class=\"info-perso-value\">{{usuario.numero}}</span>\n      </section>\n      <section class=\"info-block\" *ngIf=\"usuario.patente != ''\">\n        <span class=\"info-perso-label\">Patente</span>\n        <span class=\"info-perso-value\">{{usuario.patente}}</span>\n      </section>\n      <ion-button id=\"open-modal\" class=\"editar-perfil\" expand=\"block\" fill=\"clear\" shape=\"round\">\n        Editar perfil\n      </ion-button>\n    </div>\n  </div>\n  <!-- Modal -->\n  <ion-modal trigger=\"open-modal\" name=\"modal\" id=\"modal\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button style=\"color: red;\" (click)=\"closeModal()\">Cancelar</ion-button>\n          </ion-buttons>\n          <ion-title>Editar Perfil</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <span style=\"border-bottom: 1px solid black;\">Cambiar Foto de Perfil</span>\n        <div style=\"display: flex; flex-direction: row; margin-bottom: 2vh; margin-top: 1vh;\">\n          <img src=\"{{usuario.foto}}\" class=\"foto-perfil\"\n            *ngIf=\"usuario.foto != ''; else noFoto\">\n          <ng-template #noFoto>\n            <img src=\"../../../assets/hellokitty.png\" class=\"foto-perfil\">\n          </ng-template>\n          <ion-item>\n            <ion-label position=\"stacked\">Foto de Perfil</ion-label>\n            <input type=\"file\" (change)=\"changeImage($event)\" id=\"file-input\" accept=\"image/png, image/jpeg\">\n            <ion-button (click)=\"saveData('foto')\" expand=\"block\" fill=\"clear\" shape=\"round\" style=\"color: red;\" *ngIf=\"usuario.foto != ''\">\n              Eliminar Foto\n            </ion-button>\n          </ion-item>\n        </div>\n        <span style=\"border-bottom: 1px solid black;\">Cambiar Número de Teléfono</span>\n        <ion-item style=\"margin-bottom: 0.15vh; margin-top: 1vh;\">\n          <ion-label position=\"stacked\">Número de Teléfono</ion-label>\n          <ion-input type=\"number\" name=\"numero\" [(ngModel)]=\"changes.numero\" placeholder=\"940529144\"></ion-input>\n          <ion-button (click)=\"saveData('numero')\" expand=\"block\" fill=\"clear\" shape=\"round\" style=\"color: red;\" *ngIf=\"usuario.numero != null\">\n            Eliminar Número\n          </ion-button>\n        </ion-item>\n        <span style=\"border-bottom: 1px solid black;\">Cambiar Contraseña</span>\n        <ion-item style=\"margin-bottom: 2vh; margin-top: 1vh;\">\n          <ion-label position=\"stacked\">Contraseña</ion-label>\n          <ion-input type=\"password\" #pass name=\"password\" [(ngModel)]=\"changes.password\"></ion-input>\n          <ion-label position=\"stacked\">Repetir Contraseña</ion-label>\n          <ion-input type=\"password\" #pass2 name=\"password2\" [(ngModel)]=\"changes.password2\"></ion-input>\n        </ion-item>\n        <span *ngIf=\"usuario.patente == ''; else alreadyDriverMsg\" style=\"border-bottom: 1px solid black;\">Convertirse\n          en conductor</span>\n        <ion-item *ngIf=\"usuario.patente == ''; else alreadyDriver\">\n          <ion-button expand=\"block\" fill=\"clear\" shape=\"round\"\n            style=\"margin-bottom: 2vh; margin-top: 1vh; color: lime;\" (click)=\"changeDriverStatus()\">\n            Estoy seguro\n          </ion-button>\n        </ion-item>\n        <ng-template #alreadyDriverMsg>\n          <span style=\"border-bottom: 1px solid black;\">¿Dejar de ser conductor?</span>\n        </ng-template>\n        <ng-template #alreadyDriver>\n          <ion-item #alreadyDriver>\n            <ion-button expand=\"block\" fill=\"clear\" shape=\"round\"\n              style=\"margin-bottom: 2vh; margin-top: 1vh; color: red;\" (click)=\"changeDriverStatus()\">\n              Estoy seguro\n            </ion-button>\n          </ion-item>\n        </ng-template>\n        <ion-button (click)=\"saveData()\" expand=\"block\" fill=\"clear\" shape=\"round\">\n          Guardar cambios\n        </ion-button>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n  <!-- Fin Modal -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_perfil-usuario_perfil-usuario_module_ts.js.map