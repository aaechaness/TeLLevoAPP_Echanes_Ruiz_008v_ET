"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_recuperar-contrasena_recuperar-contrasena_module_ts"],{

/***/ 8446:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/recuperar-contrasena/recuperar-contrasena-routing.module.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecuperarContrasenaPageRoutingModule": () => (/* binding */ RecuperarContrasenaPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _recuperar_contrasena_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recuperar-contrasena.page */ 637);




const routes = [
    {
        path: '',
        component: _recuperar_contrasena_page__WEBPACK_IMPORTED_MODULE_0__.RecuperarContrasenaPage
    }
];
let RecuperarContrasenaPageRoutingModule = class RecuperarContrasenaPageRoutingModule {
};
RecuperarContrasenaPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RecuperarContrasenaPageRoutingModule);



/***/ }),

/***/ 7546:
/*!***************************************************************************!*\
  !*** ./src/app/pages/recuperar-contrasena/recuperar-contrasena.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecuperarContrasenaPageModule": () => (/* binding */ RecuperarContrasenaPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _recuperar_contrasena_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recuperar-contrasena-routing.module */ 8446);
/* harmony import */ var _recuperar_contrasena_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./recuperar-contrasena.page */ 637);







let RecuperarContrasenaPageModule = class RecuperarContrasenaPageModule {
};
RecuperarContrasenaPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _recuperar_contrasena_routing_module__WEBPACK_IMPORTED_MODULE_0__.RecuperarContrasenaPageRoutingModule
        ],
        declarations: [_recuperar_contrasena_page__WEBPACK_IMPORTED_MODULE_1__.RecuperarContrasenaPage]
    })
], RecuperarContrasenaPageModule);



/***/ }),

/***/ 637:
/*!*************************************************************************!*\
  !*** ./src/app/pages/recuperar-contrasena/recuperar-contrasena.page.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecuperarContrasenaPage": () => (/* binding */ RecuperarContrasenaPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _recuperar_contrasena_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./recuperar-contrasena.page.html?ngResource */ 3146);
/* harmony import */ var _recuperar_contrasena_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./recuperar-contrasena.page.scss?ngResource */ 6171);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);








let RecuperarContrasenaPage = class RecuperarContrasenaPage {
  constructor(_router, _alertCtrl, _auth) {
    this._router = _router;
    this._alertCtrl = _alertCtrl;
    this._auth = _auth;
    this.datos = {
      correo: '',
      codigo: '',
      contrasena: '',
      contrasena2: ''
    };
    this.codigoAutorizacion = '';
  }

  ngOnInit() {}

  generateCode() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this.codigoAutorizacion == '') {
        _this.codigoAutorizacion = Math.random().toString(36).substring(2, 9).toUpperCase();
        console.log(_this.codigoAutorizacion);

        let username = _this._auth.getUser(_this.datos.correo);

        (yield _this._auth.recoverPassword(_this.datos.correo, _this.codigoAutorizacion, username['nombre'])).subscribe(e => {});
      }
    })();
  }

  onSubmit(form) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let user = _this2._auth.getUser(_this2.datos.correo);

      yield _this2._auth.changePassword(user, _this2.datos.contrasena);
      const alert = yield _this2._alertCtrl.create({
        header: '¡Éxito!',
        subHeader: 'Cambiaste tu contraseña',
        message: 'Has cambiado tu contraseña con éxito. Volverás al menú de inicio de sesión al apretar "OK".',
        backdropDismiss: false,
        buttons: [{
          text: 'OK',
          role: 'ok',
          handler: () => {
            _this2._router.navigate(['/login']);

            form.reset();
          }
        }],
        mode: 'ios' // Las alertas son componentes globales, por lo que para editar su CSS por ejemplo, hay que editarlo en el archivo
        // global.scss que está en la carpeta src.

      });
      yield alert.present();
    })();
  }

};

RecuperarContrasenaPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}];

RecuperarContrasenaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-recuperar-contrasena',
  template: _recuperar_contrasena_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_recuperar_contrasena_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], RecuperarContrasenaPage);


/***/ }),

/***/ 6171:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/recuperar-contrasena/recuperar-contrasena.page.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = ".page-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  margin-top: 2vh;\n}\n\n.titulo {\n  font-size: 3vh;\n  font-weight: 600;\n}\n\n.instrucciones-txt {\n  margin-top: 1.5vh;\n  margin-bottom: 1.5vh;\n  text-align: center;\n  font-style: italic;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlY3VwZXJhci1jb250cmFzZW5hLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBQ0oiLCJmaWxlIjoicmVjdXBlcmFyLWNvbnRyYXNlbmEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnBhZ2UtYm9keSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMnZoO1xufVxuXG4udGl0dWxvIHtcbiAgICBmb250LXNpemU6IDN2aDtcbiAgICBmb250LXdlaWdodDogNjAwO1xufVxuXG4uaW5zdHJ1Y2Npb25lcy10eHQge1xuICAgIG1hcmdpbi10b3A6IDEuNXZoO1xuICAgIG1hcmdpbi1ib3R0b206IDEuNXZoO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XG59Il19 */";

/***/ }),

/***/ 3146:
/*!**************************************************************************************!*\
  !*** ./src/app/pages/recuperar-contrasena/recuperar-contrasena.page.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" default-href=\"/login\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"page-body\">\n    <span class=\"titulo\">Recuperar Contraseña</span>\n    <span class=\"instrucciones-txt\">Por favor ingrese su correo electrónico asociado a la cuenta para hacer el envio de un código de autorización.</span>\n    <form name=\"recuperarcontrasena\" #recuperarcontrasena=\"ngForm\" (ngSubmit)=\"onSubmit(recuperarcontrasena)\">\n      <!-- Obtener el Código -->\n      <ion-item>\n        <ion-label position=\"floating\">Correo Institucional</ion-label>\n        <ion-input required name=\"correo\" #correo=\"ngModel\" [(ngModel)]=\"datos.correo\" clear-input mode=\"ios\" pattern=\".*(@duocuc.cl|@profesor.duoc.cl)\"></ion-input>\n      </ion-item>\n      <ion-button [disabled]=\"recuperarcontrasena.invalid\" (click)=\"generateCode()\" expand=\"block\" fill=\"clear\">\n        Obtener código\n      </ion-button>\n      <!-- Ingresar el Código -->\n      <ion-item *ngIf=\"codigoAutorizacion != ''\" style=\"margin-top: 2vh; margin-bottom: 4vh;\">\n        <ion-label position=\"stacked\">Código de Autorización</ion-label>\n        <ion-input required name=\"codigo\" #codigo=\"ngModel\" [(ngModel)]=\"datos.codigo\" clear-input mode=\"ios\"></ion-input>\n      </ion-item>\n      <!-- Cambiar contraseña -->\n      <div style=\"border-top: 1px solid black; padding: 2vh; text-align: center;\" *ngIf=\"(codigoAutorizacion != '' && datos.codigo != '') && datos.codigo == codigoAutorizacion\">\n        <span style=\"font-style: italic;\">Ingresa la nueva contraseña que desees tener.</span>\n        <ion-item>\n          <ion-label position=\"floating\">Nueva Contraseña</ion-label>\n          <ion-input type=\"password\" clear-input required name=\"contrasena\" #contrasena=\"ngModel\" [(ngModel)]=\"datos.contrasena\" clear-input mode=\"ios\"></ion-input>\n        </ion-item>\n        <ion-item>\n          <ion-label position=\"floating\">Confirmar Contraseña</ion-label>\n          <ion-input type=\"password\" clear-input required name=\"contrasena2\" #contrasena2=\"ngModel\" [(ngModel)]=\"datos.contrasena2\" clear-input mode=\"ios\"></ion-input>\n        </ion-item>\n        <ion-button type=\"submit\" [disabled]=\"datos.contrasena != datos.contrasena2 || datos.contrasena == ''\" expand=\"block\" fill=\"clear\" style=\"margin-top: 2vh;\">\n          Cambiar contraseña\n        </ion-button>\n      </div>\n    </form>\n  </div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_recuperar-contrasena_recuperar-contrasena_module_ts.js.map