"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_tus-viajes_tus-viajes_module_ts"],{

/***/ 4885:
/*!***************************************************************!*\
  !*** ./src/app/pages/tus-viajes/tus-viajes-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TusViajesPageRoutingModule": () => (/* binding */ TusViajesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _tus_viajes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tus-viajes.page */ 4542);




const routes = [
    {
        path: '',
        component: _tus_viajes_page__WEBPACK_IMPORTED_MODULE_0__.TusViajesPage
    }
];
let TusViajesPageRoutingModule = class TusViajesPageRoutingModule {
};
TusViajesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TusViajesPageRoutingModule);



/***/ }),

/***/ 1948:
/*!*******************************************************!*\
  !*** ./src/app/pages/tus-viajes/tus-viajes.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TusViajesPageModule": () => (/* binding */ TusViajesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _tus_viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tus-viajes-routing.module */ 4885);
/* harmony import */ var _tus_viajes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tus-viajes.page */ 4542);







let TusViajesPageModule = class TusViajesPageModule {
};
TusViajesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _tus_viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__.TusViajesPageRoutingModule
        ],
        declarations: [_tus_viajes_page__WEBPACK_IMPORTED_MODULE_1__.TusViajesPage]
    })
], TusViajesPageModule);



/***/ }),

/***/ 4542:
/*!*****************************************************!*\
  !*** ./src/app/pages/tus-viajes/tus-viajes.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TusViajesPage": () => (/* binding */ TusViajesPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _tus_viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tus-viajes.page.html?ngResource */ 6809);
/* harmony import */ var _tus_viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tus-viajes.page.scss?ngResource */ 965);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);








let TusViajesPage = class TusViajesPage {
  constructor(_router, _auth, _viajes) {
    this._router = _router;
    this._auth = _auth;
    this._viajes = _viajes;
    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.viajes = [];
    this.viaje = {
      id: null,
      fecha: null,
      destino: '',
      precio: null,
      capacidad: null,
      descripcion: '',
      conductor: null,
      pasajeros: [],
      valoraciones: [],
      estatus: null
    };
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.usuario = yield _this._auth.getSession();
      let viajes = yield _this._viajes.get();
      viajes.viajes.forEach(viaje => {
        if (viaje.conductor === _this.usuario.correo) {
          let viajeRaw = viaje;
          viajeRaw['translatedDate'] = _this._viajes.translateDate(new Date(viajeRaw.fecha.toString()));

          _this.viajes.push(viajeRaw);
        }
      });
    })();
  }

  seeViajeDetails(id) {
    this._router.navigate(['/viaje'], {
      queryParams: {
        id: id
      }
    });
  }

};

TusViajesPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}];

TusViajesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-tus-viajes',
  template: _tus_viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tus_viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], TusViajesPage);


/***/ }),

/***/ 965:
/*!******************************************************************!*\
  !*** ./src/app/pages/tus-viajes/tus-viajes.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ".content-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.resumen-lista-viajes {\n  display: flex;\n  flex-direction: column;\n  margin-top: 2vh;\n  width: 80%;\n}\n\n.resumen-lista-viajes-viaje {\n  display: flex;\n  flex-direction: column;\n  margin: 2vh 0vh;\n  border: 0.25px solid;\n  padding: 1vh;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInR1cy12aWFqZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQ0YiLCJmaWxlIjoidHVzLXZpYWplcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGVudC1ib2R5IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnJlc3VtZW4tbGlzdGEtdmlhamVzIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWFyZ2luLXRvcDogMnZoO1xyXG4gIHdpZHRoOiA4MCVcclxufVxyXG5cclxuLnJlc3VtZW4tbGlzdGEtdmlhamVzLXZpYWplIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWFyZ2luOiAydmggMHZoO1xyXG4gIGJvcmRlcjogMC4yNXB4IHNvbGlkO1xyXG4gIHBhZGRpbmc6IDF2aDtcclxuICB3aWR0aDogMTAwJTtcclxufSJdfQ== */";

/***/ }),

/***/ 6809:
/*!******************************************************************!*\
  !*** ./src/app/pages/tus-viajes/tus-viajes.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" routerLink=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"content-body\">\n    <section *ngIf=\"usuario.patente != ''\" style=\"margin: 1.5vh 0vh;\">\n      <ion-item>\n        <div style=\"display: flex; flex-direction: column; align-items: center; margin: 0vh 4vh;\"\n          (click)=\"_router.navigate(['viajes'])\">\n          <ion-icon name=\"list-outline\" style=\"width: 4vh; height: 4vh;\"></ion-icon>\n          <ion-label>Todos los Viajes</ion-label>\n        </div>\n        <div style=\"display: flex; flex-direction: column; align-items: center; margin: 0vh 4vh;\">\n          <ion-icon name=\"car-outline\" style=\"width: 4vh; height: 4vh;\"></ion-icon>\n          <ion-label>Tus Viajes</ion-label>\n        </div>\n      </ion-item>\n    </section>\n    <section class=\"resumen-lista-viajes\" *ngIf=\"viajes.length > 0; else notEnoughtViajes\">\n      <!--? ngFor -->\n      <ion-item style=\"border: 1px solid; border-radius: 1vh; margin: 0.75vh 0vh;\" *ngFor=\"let viaje of viajes; index as x\">\n        <ion-label>\n          <p style=\"margin-bottom: 0.5vh;\">\n            {{viaje.translatedDate}}\n          </p>\n          <span style=\"margin: 0.25vh 0vh;\">{{viaje.destino}}</span>\n          <p style=\"margin-top: 0.5vh;\">\n            {{viaje.capacidad - viaje.pasajeros.length}} Disponible(s) | ${{viaje.precio}} de Tarifa\n          </p>\n          <!--? Estado del Viaje -->\n          <p *ngIf=\"viaje.estatus == 'Completado'\"\n          style=\"color: var(--ion-color-success); font-size: 2vh; margin-bottom: 1vh; display: flex;\n          align-items: center;\">\n            <ion-icon name=\"checkmark-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n          <p *ngIf=\"viaje.estatus == 'Pendiente'\" style=\"color: var(--ion-color-warning); font-size: 2vh;\n          margin-bottom: 1vh; display: flex; align-items: center;\">\n            <ion-icon name=\"time-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n          <p *ngIf=\"viaje.estatus == 'Cancelado'\" style=\"color: var(--ion-color-danger); font-size: 2vh;\n          margin-bottom: 1vh; display: flex; align-items: center;\">\n            <ion-icon name=\"close-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n          <!--? Detalles -->\n          <a (click)=\"seeViajeDetails(viaje.id)\">Ver información completa</a>\n        </ion-label>\n      </ion-item>\n      <!--? Fin ngFor -->\n    </section>\n    <ng-template #notEnoughtViajes>\n      <div\n        style=\"margin: 2.5vh 0vh; display: flex; flex-direction: column; align-content: center; justify-content: center; align-items: center;\">\n        <span style=\"color: red; text-align: center;\">No has programado ningún viaje</span>\n        <a (click)=\"_router.navigate(['programar-viaje'])\" style=\"text-align: center; margin: 1vh 0vh;\">¿Deseas\n          programar uno nuevo?</a>\n      </div>\n    </ng-template>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_tus-viajes_tus-viajes_module_ts.js.map