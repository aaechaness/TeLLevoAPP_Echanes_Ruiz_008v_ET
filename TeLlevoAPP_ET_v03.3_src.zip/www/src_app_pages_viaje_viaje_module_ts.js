"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_viaje_viaje_module_ts"],{

/***/ 854:
/*!*****************************************************!*\
  !*** ./src/app/pages/viaje/viaje-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajePageRoutingModule": () => (/* binding */ ViajePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _viaje_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./viaje.page */ 1102);




const routes = [
    {
        path: '',
        component: _viaje_page__WEBPACK_IMPORTED_MODULE_0__.ViajePage
    }
];
let ViajePageRoutingModule = class ViajePageRoutingModule {
};
ViajePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ViajePageRoutingModule);



/***/ }),

/***/ 9809:
/*!*********************************************!*\
  !*** ./src/app/pages/viaje/viaje.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajePageModule": () => (/* binding */ ViajePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _viaje_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./viaje-routing.module */ 854);
/* harmony import */ var _viaje_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./viaje.page */ 1102);







let ViajePageModule = class ViajePageModule {
};
ViajePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _viaje_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViajePageRoutingModule
        ],
        declarations: [_viaje_page__WEBPACK_IMPORTED_MODULE_1__.ViajePage]
    })
], ViajePageModule);



/***/ }),

/***/ 1102:
/*!*******************************************!*\
  !*** ./src/app/pages/viaje/viaje.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajePage": () => (/* binding */ ViajePage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _viaje_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./viaje.page.html?ngResource */ 8791);
/* harmony import */ var _viaje_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./viaje.page.scss?ngResource */ 3479);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);
/* harmony import */ var src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/enums/agendar-status */ 4774);
/* harmony import */ var src_app_services_valoracion_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/valoracion.service */ 2493);












let ViajePage = class ViajePage {
  constructor(_router, _route, _auth, _viajes, _modalCtrl, _toastCtrl, _animCtrl, _valoracion) {
    this._router = _router;
    this._route = _route;
    this._auth = _auth;
    this._viajes = _viajes;
    this._modalCtrl = _modalCtrl;
    this._toastCtrl = _toastCtrl;
    this._animCtrl = _animCtrl;
    this._valoracion = _valoracion;
    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.viaje = {
      id: null,
      fecha: null,
      destino: '',
      precio: null,
      capacidad: null,
      descripcion: '',
      conductor: null,
      pasajeros: [],
      valoraciones: [],
      estatus: null
    };
    this.conductor = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.valoracion = {
      calificacion: 0,
      comentario: ''
    };
    this.pasajeros = [];
    this.hoy = new Date().toISOString();
    this.gotTheRide = false;
    this.hasDisplayedPasajeros = false;
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.pasajeros = [];
      _this.usuario = yield _this._auth.getSession();

      _this._route.queryParams.subscribe( /*#__PURE__*/function () {
        var _ref = (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (params) {
          if (params) {
            _this.viaje = yield _this._viajes.getViaje(parseInt(params['id']));
            _this.conductor = _this._auth.getUser(_this.viaje.conductor);

            _this.viaje.pasajeros.forEach(pasajero => {
              _this.pasajeros.push(_this._auth.getUser(pasajero));
            });

            const fecha = new Date(_this.viaje.fecha);
            _this.viaje['translatedDate'] = _this._viajes.translateDate(fecha);
            _this.gotTheRide = _this.viaje.pasajeros.includes(_this.usuario.correo);
            _this.didQualified = _this._valoracion.userDidRate(_this.usuario.correo, _this.viaje.id);
          }
        });

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }()); //this.viaje = this._viajes.getViaje(id)

    })();
  }

  onSubmit() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.viaje.fecha = new Date(_this2.fecha.value.toString());
      let edited = yield _this2._viajes.editViaje(_this2.viaje, _this2.usuario);

      if (edited) {
        let toast = yield _this2._toastCtrl.create({
          message: '¡Has modificado tu Viaje!',
          duration: 2000,
          icon: 'sparkles-outline'
        });
        yield toast.present();

        _this2.closeModal();

        yield _this2.loadData();
      } else {
        let toast = yield _this2._toastCtrl.create({
          message: 'No se ha podido modificar tu Viaje',
          duration: 2000,
          icon: 'sad-outline'
        });
        yield toast.present();
      }
    })();
  }

  displayPasajeros() {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let animacion = _this3._animCtrl.create().addElement(document.getElementsByClassName('pasajeros-details')[0]).duration(100);

      if (_this3.hasDisplayedPasajeros) {
        _this3.hasDisplayedPasajeros = false;
        animacion.fromTo('transform', 'rotate(90deg)', 'rotate(0deg)');
        yield animacion.play();
      } else {
        _this3.hasDisplayedPasajeros = true;
        animacion.fromTo('transform', 'rotate(0deg)', 'rotate(90deg)');
        yield animacion.play();
      }
    })();
  }

  goToProfile(correo) {
    this._router.navigate(['/perfil-otros'], {
      queryParams: {
        correo: correo
      }
    });
  }

  reservar() {
    var _this4 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let isDone = yield _this4._viajes.getRide(_this4.viaje.id, _this4.usuario);

      if (isDone === src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__.AgendarStatus.DONE) {
        let toast = yield _this4._toastCtrl.create({
          message: 'Viaje Agendado!',
          duration: 1500,
          icon: 'checkmark-circle-outline'
        });
        yield toast.present();
        yield _this4.loadData();
      } else if (isDone === src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__.AgendarStatus.ALREADY_TAKEN) {
        let toast = yield _this4._toastCtrl.create({
          message: 'Ya agendaste este Viaje',
          duration: 3000,
          icon: 'alert-circle-outline',
          buttons: [{
            text: 'Cancelar',
            role: 'cancelarViaje',
            handler: () => {
              console.log('Viaje cancelado');
            }
          }, {
            text: 'Descartar',
            role: 'cancel',
            handler: () => {
              console.log('Chau');
            }
          }]
        });
        yield toast.present();
      } else {
        let toast = yield _this4._toastCtrl.create({
          message: 'No fue posible agendar este viaje',
          duration: 1500,
          icon: 'sad-outline'
        });
        yield toast.present();
      }
    })();
  }

  cancelarReserva() {
    var _this5 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let cancelado = yield _this5._viajes.cancelRide(_this5.viaje.id, _this5.usuario);

      if (cancelado) {
        const toast = yield _this5._toastCtrl.create({
          message: 'Has cancelado tu reserva',
          duration: 1500,
          position: 'bottom',
          icon: "close-circle-outline"
        });
        yield toast.present();
        yield _this5.loadData();
      } else {
        const toast = yield _this5._toastCtrl.create({
          message: 'No se pudo cancelar tu reserva',
          duration: 1500,
          position: 'bottom',
          icon: "alert-circle-outline"
        });
        yield toast.present();
      }
    })();
  }

  cancelarViaje() {
    var _this6 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let cancelado = yield _this6._viajes.cancelViaje(_this6.viaje.id, _this6.usuario);

      if (cancelado) {
        const toast = yield _this6._toastCtrl.create({
          message: 'Has cancelado tu viaje',
          duration: 1500,
          position: 'bottom',
          icon: "close-circle-outline"
        });
        yield toast.present();
        yield _this6.loadData();
      } else {
        const toast = yield _this6._toastCtrl.create({
          message: 'No se pudo cancelar tu viaje',
          duration: 1500,
          position: 'bottom',
          icon: "alert-circle-outline"
        });
        yield toast.present();
      }
    })();
  }

  pinFormatter(value) {
    return `${Math.round(value / 10)}`;
  }

  valorarViaje() {
    var _this7 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this7.valoracion.calificacion = Math.round(_this7.calificacion['value'] / 10);

      _this7._valoracion.addValoracion(_this7.viaje, _this7.usuario, _this7.valoracion.calificacion, _this7.valoracion.comentario);

      _this7._modalCtrl.getTop().then(modal => modal.dismiss());

      yield _this7.loadData();
      const toast = yield _this7._toastCtrl.create({
        message: '¡Has valorado el Viaje!',
        duration: 1500,
        position: 'bottom',
        icon: "star-outline"
      });
      yield toast.present();

      _this7._router.navigate(['/historial-viajes']);
    })();
  }

  closeModal() {
    this._modalCtrl.getTop().then(modal => modal.dismiss());
  }

};

ViajePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AnimationController
}, {
  type: src_app_services_valoracion_service__WEBPACK_IMPORTED_MODULE_6__.ValoracionService
}];

ViajePage.propDecorators = {
  fecha: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['fecha']
  }],
  calificacion: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_9__.ViewChild,
    args: ['calificacion']
  }]
};
ViajePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-viaje',
  template: _viaje_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_viaje_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ViajePage);


/***/ }),

/***/ 3479:
/*!********************************************************!*\
  !*** ./src/app/pages/viaje/viaje.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ".content-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpYWplLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7QUFDSiIsImZpbGUiOiJ2aWFqZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGVudC1ib2R5IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn0iXX0= */";

/***/ }),

/***/ 8791:
/*!********************************************************!*\
  !*** ./src/app/pages/viaje/viaje.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Detalles del Viaje</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"content-body\">\n    <ion-list>\n      <!--* Destino -->\n      <ion-item>\n        <ion-label>\n          <span style=\"font-size: 2.5vh; border-bottom: 1px solid; padding: 0.25vh 0vh;\">\n            Destino\n          </span>\n          <p style=\"font-size: 2vh; margin-top: 1.25vh;\">{{viaje.destino}}</p>\n        </ion-label>\n      </ion-item>\n      <!--* Conductor -->\n      <ion-item (click)=\"goToProfile(conductor.correo)\">\n        <ion-label>\n          <span style=\"font-size: 2.5vh; border-bottom: 1px solid; padding: 0.25vh 0vh;\">\n            Conductor\n          </span>\n          <ion-item style=\"font-size: 2vh; margin-top: 1.25vh;\">\n            <label *ngIf=\"conductor.foto != ''; else doesntHaveFoto\">\n              <a\n                style=\"display: flex; flex-direction: row; align-content: center; justify-content: center; align-items: center;\">\n                <img src=\"{{conductor.foto}}\" style=\"width: 4vh; height: 4vh; border: 1px solid; margin-right: 1vh;\">\n                {{conductor.nombre}}\n              </a>\n            </label>\n            <ng-template #doesntHaveFoto>\n              <label>\n                <a\n                  style=\"display: flex; flex-direction: row; align-content: center; justify-content: center; align-items: center;\">\n                  <img src=\"./../../../assets/hellokitty.png\"\n                    style=\"width: 4vh; height: 4vh; border: 1px solid; margin-right: 1vh;\"> {{conductor.nombre}}\n                </a>\n              </label>\n            </ng-template>\n          </ion-item>\n        </ion-label>\n      </ion-item>\n      <!--* Capacidad & Precio -->\n      <ion-item>\n        <ion-label>\n          <span style=\"font-size: 2.5vh; border-bottom: 1px solid; padding: 0.25vh 0vh;\">\n            Capacidad y Precio\n          </span>\n          <p style=\"font-size: 2vh; margin-top: 1.25vh;\">\n            {{viaje.capacidad}} personas | ${{viaje.precio}}/persona\n          </p>\n          <p style=\"font-size: 1.8vh; color: green;\">\n            ({{viaje.capacidad - viaje.pasajeros.length}} disponibles)\n          </p>\n        </ion-label>\n      </ion-item>\n      <!--* Fecha -->\n      <ion-item>\n        <ion-label>\n          <span style=\"font-size: 2.5vh; border-bottom: 1px solid; padding: 0.25vh 0vh;\">\n            Fecha\n          </span>\n          <p style=\"font-size: 2vh; margin-top: 1.25vh;\">{{viaje.translatedDate}}</p>\n        </ion-label>\n      </ion-item>\n      <!--* Estado del Viaje -->\n      <ion-item>\n        <ion-label>\n          <span style=\"font-size: 2.5vh; border-bottom: 1px solid; padding: 0.25vh 0vh;\">\n            Estado del Viaje\n          </span>\n          <p *ngIf=\"viaje.estatus == 'Completado'\"\n            style=\"color: var(--ion-color-success); font-size: 2vh; margin-top: 1.25vh; display: flex; align-items: center;\">\n            <ion-icon name=\"checkmark-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n          <p *ngIf=\"viaje.estatus == 'Pendiente'\"\n            style=\"color: var(--ion-color-warning); font-size: 2vh; margin-top: 1.25vh; display: flex; align-items: center;\">\n            <ion-icon name=\"time-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n          <p *ngIf=\"viaje.estatus == 'Cancelado'\"\n            style=\"color: var(--ion-color-danger); font-size: 2vh; margin-top: 1.25vh; display: flex; align-items: center;\">\n            <ion-icon name=\"close-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n          </p>\n        </ion-label>\n      </ion-item>\n      <!--* Pasajeros -->\n      <ion-item (click)=\"displayPasajeros()\">\n        <ion-label>\n          <span style=\"font-size: 2.5vh;\">Pasajeros</span>\n        </ion-label>\n        <ion-icon class=\"pasajeros-details\" name=\"chevron-forward-outline\" slot=\"end\"></ion-icon>\n      </ion-item>\n      <ion-list *ngIf=\"hasDisplayedPasajeros\">\n        <ion-list *ngIf=\"pasajeros.length > 0; else noPassengers\">\n          <ion-item (click)=\"goToProfile(pasajero.correo)\" *ngFor=\"let pasajero of pasajeros\">\n            <ion-avatar slot=\"start\">\n              <img *ngIf=\"pasajero.foto != ''; else noPfp\" src=\"{{pasajero.foto}}\">\n              <ng-template #noPfp>\n                <img src=\"./../../../assets/hellokitty.png\">\n              </ng-template>\n            </ion-avatar>\n            <ion-label>\n              {{pasajero.nombre}}\n            </ion-label>\n          </ion-item>\n        </ion-list>\n        <ng-template #noPassengers>\n          <ion-item lines=\"none\">\n            <ion-note color=\"danger\">No hay pasajeros en este viaje</ion-note>\n          </ion-item>\n        </ng-template>\n      </ion-list>\n      <!--? Opciones de Conductor -->\n      <ion-item *ngIf=\"conductor.correo === usuario.correo\">\n        <ion-button id=\"editar-viaje-mdl\" style=\"color: var(--ion-color-warning); margin: 0vh 1vh;\" fill=\"clear\"\n          shape=\"round\" [disabled]=\"viaje.estatus !== 'Pendiente'\">\n          <ion-icon name=\"pencil-outline\" style=\"margin-right: 1vh;\"></ion-icon> Editar Viaje\n        </ion-button>\n        <ion-button (click)=\"cancelarViaje()\" style=\"color: var(--ion-color-danger); margin: 0vh 1vh;\" fill=\"clear\"\n          shape=\"round\" [disabled]=\"viaje.estatus !== 'Pendiente'\">\n          <ion-icon name=\"ban-outline\" style=\"margin-right: 1vh;\"></ion-icon> Cancelar Viaje\n        </ion-button>\n      </ion-item>\n      <!--? Opciones de Usuario que tiene el Viaje -->\n      <ion-item *ngIf=\"gotTheRide\">\n        <ion-button [disabled]=\"viaje.estatus != 'Pendiente'\" (click)=\"cancelarReserva()\"\n          style=\"color: var(--ion-color-danger); margin-top: 2vh; font-size: 2vh;\" fill=\"clear\" shape=\"round\">\n          <ion-icon name=\"ban-outline\" style=\"margin-right: 1vh;\"></ion-icon> Cancelar Reserva\n        </ion-button>\n      </ion-item>\n      <ion-button style=\"display: flex; align-self: center;\" *ngIf=\"gotTheRide && viaje.estatus == 'Completado'\"\n        [disabled]=\"didQualified\" id=\"valorar-viaje-mdl\" fill=\"clear\" shape=\"round\" color=\"warning\">\n        <ion-icon slot=\"start\" name=\"star-outline\"></ion-icon> Valorar\n      </ion-button>\n      <!--? Opciones de Usuario que no es el conductor y no tiene el viaje -->\n      <ion-item *ngIf=\"!gotTheRide && conductor.correo !== usuario.correo\">\n        <ion-button [disabled]=\"viaje.estatus != 'Pendiente'\" (click)=\"reservar()\"\n          style=\"color: var(--ion-color-primary); margin-top: 2vh; font-size: 2vh;\" fill=\"clear\" shape=\"round\">\n          <ion-icon name=\"checkmark-outline\" style=\"margin-right: 1vh;\"></ion-icon> Reservar Viaje\n        </ion-button>\n      </ion-item>\n    </ion-list>\n  </div>\n  <!--? Modal Valorar -->\n  <ion-modal #valorarviaje trigger=\"valorar-viaje-mdl\" name=\"valorar-viaje\" id=\"valorar-viaje\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button style=\"color: red;\" (click)=\"closeModal()\">Cancelar</ion-button>\n          </ion-buttons>\n          <ion-title>Editar Viaje</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <form #valorarviaje=\"ngForm\" (ngSubmit)=\"valorarViaje()\">\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Ingresa una calificación</ion-label>\n            <ion-range #calificacion [pin]=\"true\" [pinFormatter]=\"pinFormatter\">\n              <ion-icon slot=\"start\" name=\"sad-outline\"></ion-icon>\n              <ion-icon slot=\"end\" name=\"happy-outline\"></ion-icon>\n            </ion-range>\n          </ion-item>\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Descripción (opcional)</ion-label>\n            <ion-textarea name=\"descripcion\" [(ngModel)]=\"valoracion.comentario\"\n              placeholder=\"Fue un viaje muy...\" mode=\"ios\"></ion-textarea>\n          </ion-item>\n          <ion-button [disabled]=\"valorarviaje.invalid\" type=\"submit\" expand=\"block\" fill=\"clear\" shape=\"round\">\n            Valorar\n          </ion-button>\n        </form>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n  <!--? Modal Editar -->\n  <ion-modal #editarviaje trigger=\"editar-viaje-mdl\" name=\"editar-viaje\" id=\"editar-viaje\">\n    <ng-template>\n      <ion-header>\n        <ion-toolbar>\n          <ion-buttons slot=\"start\">\n            <ion-button style=\"color: red;\" (click)=\"closeModal()\">Cancelar</ion-button>\n          </ion-buttons>\n          <ion-title>Editar Viaje</ion-title>\n        </ion-toolbar>\n      </ion-header>\n      <ion-content class=\"ion-padding\">\n        <form #unviaje=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Ingresa el destino</ion-label>\n            <ion-input type=\"text\" placeholder=\"Los Copihues, Talcahuano\" name=\"destino\" [(ngModel)]=\"viaje.destino\"\n              mode=\"ios\" required></ion-input>\n          </ion-item>\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Ingresa el precio</ion-label>\n            <ion-input type=\"number\" placeholder=\"2500\" name=\"precio\" [(ngModel)]=\"viaje.precio\" mode=\"ios\" required\n              min=\"1000\">\n            </ion-input>\n          </ion-item>\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Ingresa la capacidad</ion-label>\n            <ion-input type=\"number\" placeholder=\"4\" name=\"capacidad\" [(ngModel)]=\"viaje.capacidad\" mode=\"ios\" required\n              max=10 min=1>\n            </ion-input>\n          </ion-item>\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Selecciona una Fecha y Hora</ion-label>\n            <ion-datetime-button style=\"margin-top: 1vh;\" datetime=\"datetime\">\n              <span slot=\"time-label\">Hora</span>\n            </ion-datetime-button>\n            <ion-modal [keepContentsMounted]=\"true\">\n              <ng-template>\n                <ion-datetime id=\"datetime\" name=\"fecha\" #fecha locale=\"es-CL\" hourCycle=\"h23\" min=\"{{hoy}}\">\n                </ion-datetime>\n              </ng-template>\n            </ion-modal>\n          </ion-item>\n          <ion-item style=\"margin: 2vh 0vh;\">\n            <ion-label position=\"stacked\">Descripción (opcional)</ion-label>\n            <ion-textarea name=\"descripcion\" [(ngModel)]=\"viaje.descripcion\"\n              placeholder=\"Auto de marca ... y color ..., estacionado en ...\" mode=\"ios\"></ion-textarea>\n          </ion-item>\n          <ion-button [disabled]=\"editarviaje.invalid\" type=\"submit\" expand=\"block\" fill=\"clear\" shape=\"round\">\n            Agregar\n          </ion-button>\n        </form>\n      </ion-content>\n    </ng-template>\n  </ion-modal>\n  <!-- Fin Modal -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_viaje_viaje_module_ts.js.map