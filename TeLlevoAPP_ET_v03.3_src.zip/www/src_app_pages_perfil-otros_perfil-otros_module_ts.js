"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_perfil-otros_perfil-otros_module_ts"],{

/***/ 5091:
/*!***************************************************************!*\
  !*** ./src/app/components/valoracion/valoracion.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValoracionComponent": () => (/* binding */ ValoracionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _valoracion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./valoracion.component.html?ngResource */ 1237);
/* harmony import */ var _valoracion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./valoracion.component.scss?ngResource */ 640);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);




let ValoracionComponent = class ValoracionComponent {
    constructor() { }
    ngOnInit() {
        console.log(this.valoracion);
        if (this.valoracion > 0) {
            let qualification = document.getElementsByClassName('calificacion')[0];
            let halfStar = this.valoracion % 1;
            for (let x = 0; x < this.valoracion - halfStar; x++) {
                qualification.innerHTML += `<ion-icon name="star"></ion-icon>`;
            }
            if (halfStar > 0)
                qualification.innerHTML += `<ion-icon name="star-half"></ion-icon>`;
            for (let x = 0; x < (5 - this.valoracion) - halfStar; x++) {
                qualification.innerHTML += `<ion-icon name="star-outline"></ion-icon>`;
            }
        }
    }
    loadQualification() {
        //let qualification = document.getElementsByClassName('calificacion')[0];
        //let halfStar = this.calificacion % 1;
        //for (let x = 0; x < this.calificacion - halfStar; x++) {
        //  qualification.innerHTML += `<ion-icon name="star"></ion-icon>`;
        //}
        //if (halfStar > 0) qualification.innerHTML += `<ion-icon name="star-half"></ion-icon>`;
        //for (let x = 0; x < (5 - this.calificacion) - halfStar; x++) {
        //  qualification.innerHTML += `<ion-icon name="star-outline"></ion-icon>`;
        //}
        //qualification.innerHTML += `<span style="color: black; border-bottom: 1px solid black; margin-left: 1vh;">${this.calificacion}</span>`
    }
};
ValoracionComponent.ctorParameters = () => [];
ValoracionComponent.propDecorators = {
    valoracion: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    total: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
ValoracionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'reputacion',
        template: _valoracion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_valoracion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ValoracionComponent);



/***/ }),

/***/ 3276:
/*!*******************************************************************!*\
  !*** ./src/app/pages/perfil-otros/perfil-otros-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilOtrosPageRoutingModule": () => (/* binding */ PerfilOtrosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _perfil_otros_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil-otros.page */ 4913);




const routes = [
    {
        path: '',
        component: _perfil_otros_page__WEBPACK_IMPORTED_MODULE_0__.PerfilOtrosPage
    }
];
let PerfilOtrosPageRoutingModule = class PerfilOtrosPageRoutingModule {
};
PerfilOtrosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PerfilOtrosPageRoutingModule);



/***/ }),

/***/ 8336:
/*!***********************************************************!*\
  !*** ./src/app/pages/perfil-otros/perfil-otros.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilOtrosPageModule": () => (/* binding */ PerfilOtrosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _perfil_otros_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./perfil-otros-routing.module */ 3276);
/* harmony import */ var _perfil_otros_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil-otros.page */ 4913);
/* harmony import */ var _components_valoracion_valoracion_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/valoracion/valoracion.component */ 5091);








let PerfilOtrosPageModule = class PerfilOtrosPageModule {
};
PerfilOtrosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _perfil_otros_routing_module__WEBPACK_IMPORTED_MODULE_0__.PerfilOtrosPageRoutingModule,
        ],
        declarations: [_perfil_otros_page__WEBPACK_IMPORTED_MODULE_1__.PerfilOtrosPage, _components_valoracion_valoracion_component__WEBPACK_IMPORTED_MODULE_2__.ValoracionComponent]
    })
], PerfilOtrosPageModule);



/***/ }),

/***/ 4913:
/*!*********************************************************!*\
  !*** ./src/app/pages/perfil-otros/perfil-otros.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PerfilOtrosPage": () => (/* binding */ PerfilOtrosPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _perfil_otros_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./perfil-otros.page.html?ngResource */ 6981);
/* harmony import */ var _perfil_otros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./perfil-otros.page.scss?ngResource */ 2304);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_reportes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/reportes.service */ 9216);
/* harmony import */ var src_app_services_valoracion_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/valoracion.service */ 2493);










let PerfilOtrosPage = class PerfilOtrosPage {
  constructor(_modalCtrl, _alertCtrl, _route, _auth, _valoracion, _reportes) {
    this._modalCtrl = _modalCtrl;
    this._alertCtrl = _alertCtrl;
    this._route = _route;
    this._auth = _auth;
    this._valoracion = _valoracion;
    this._reportes = _reportes; //? Usuario sesión

    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    }; //? Usuario a mostrar

    this.usuarioAMostrar = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.valoracion = []; // Esto es sólo para rellenar, luego hay que cambiarlo.

    this.reporte = {
      motivo: '',
      descripcion: ''
    };
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //? Cargar usuario
      _this.usuario = yield _this._auth.getSession(); //? Cargar usuario a mostrar

      _this._route.queryParams.subscribe(params => {
        if (params) _this.usuarioAMostrar = _this._auth.getUser(params.correo);
      }); //? Cargar valoración


      _this.valoracion = yield _this._valoracion.getValoracion(_this.usuarioAMostrar); //this.valoracion = this._valoracion.getValoracion(this.usuario);
      //console.log(this.valoracion.constructor)
    })();
  }

  closeModal() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2._modalCtrl.dismiss('modal', 'cancelar');
    })();
  }

  onSubmit(form) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3._reportes.reportUser(_this3.usuario, _this3.usuarioAMostrar, {
        motivo: _this3.reporte.motivo,
        descripcion: _this3.reporte.descripcion
      });
      const alert = yield _this3._alertCtrl.create({
        header: '¡Éxito!',
        subHeader: 'Reportaste con éxito',
        message: 'Has reportado con éxito al usuario ' + _this3.usuarioAMostrar.nombre + '. Presiona "OK" para volver a su Perfil.',
        backdropDismiss: false,
        buttons: [{
          text: 'OK',
          role: 'ok',
          handler: () => {
            _this3.closeModal();

            form.reset();
          }
        }],
        mode: 'ios'
      });
      yield alert.present();
    })();
  }

};

PerfilOtrosPage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_valoracion_service__WEBPACK_IMPORTED_MODULE_5__.ValoracionService
}, {
  type: src_app_services_reportes_service__WEBPACK_IMPORTED_MODULE_4__.ReportesService
}];

PerfilOtrosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-perfil-otros',
  template: _perfil_otros_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_perfil_otros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], PerfilOtrosPage);


/***/ }),

/***/ 640:
/*!****************************************************************************!*\
  !*** ./src/app/components/valoracion/valoracion.component.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2YWxvcmFjaW9uLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 2304:
/*!**********************************************************************!*\
  !*** ./src/app/pages/perfil-otros/perfil-otros.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".body-page {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.body-page img {\n  width: 18vh;\n  height: 18vh;\n  border-radius: 4vh;\n  border: 1.5px solid;\n}\n\n.nombreUsuario {\n  font-size: 3vh;\n  margin-top: 1.5vh;\n  margin-bottom: 0.5vh;\n}\n\n.calificacion {\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: center;\n}\n\n.calificacion::content {\n  margin: 1vh 1.5vh;\n  color: gold;\n  font-size: 2.5vh;\n}\n\n.informacion-usuario {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n  margin-top: 2vh;\n  padding: 2vh;\n  border: 1px solid;\n  border-radius: 2vh;\n}\n\n.informacion-usuario div {\n  display: flex;\n  flex-direction: row;\n  margin: 1vh 2vh;\n}\n\n.info-user-titulo {\n  border-bottom: 1px solid;\n  margin-right: 1vh;\n}\n\n.reportar-usuario::content {\n  margin-top: 2vh;\n  color: red;\n}\n\n.form-content {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  margin-top: 2vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcmZpbC1vdHJvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQUNKOztBQUVBO0VBQ0ksd0JBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtFQUNBLFVBQUE7QUFDSjs7QUFFQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FBQ0oiLCJmaWxlIjoicGVyZmlsLW90cm9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib2R5LXBhZ2Uge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uYm9keS1wYWdlIGltZyB7XG4gICAgd2lkdGg6IDE4dmg7XG4gICAgaGVpZ2h0OiAxOHZoO1xuICAgIGJvcmRlci1yYWRpdXM6IDR2aDtcbiAgICBib3JkZXI6IDEuNXB4IHNvbGlkO1xufVxuXG4ubm9tYnJlVXN1YXJpbyB7XG4gICAgZm9udC1zaXplOiAzdmg7XG4gICAgbWFyZ2luLXRvcDogMS41dmg7XG4gICAgbWFyZ2luLWJvdHRvbTogMC41dmg7XG59XG5cbi5jYWxpZmljYWNpb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4uY2FsaWZpY2FjaW9uOjpjb250ZW50IHtcbiAgICBtYXJnaW46IDF2aCAxLjV2aDtcbiAgICBjb2xvcjogZ29sZDtcbiAgICBmb250LXNpemU6IDIuNXZoO1xufVxuXG4uaW5mb3JtYWNpb24tdXN1YXJpbyB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIG1hcmdpbi10b3A6IDJ2aDtcbiAgICBwYWRkaW5nOiAydmg7XG4gICAgYm9yZGVyOiAxcHggc29saWQ7XG4gICAgYm9yZGVyLXJhZGl1czogMnZoO1xufVxuXG4uaW5mb3JtYWNpb24tdXN1YXJpbyBkaXYge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgICBtYXJnaW46IDF2aCAydmg7XG59XG5cbi5pbmZvLXVzZXItdGl0dWxvIHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQ7XG4gICAgbWFyZ2luLXJpZ2h0OiAxdmg7XG59XG5cbi5yZXBvcnRhci11c3VhcmlvOjpjb250ZW50IHtcbiAgICBtYXJnaW4tdG9wOiAydmg7XG4gICAgY29sb3I6IHJlZDtcbn1cblxuLmZvcm0tY29udGVudCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgbWFyZ2luLXRvcDogMnZoO1xufSJdfQ== */";

/***/ }),

/***/ 1237:
/*!****************************************************************************!*\
  !*** ./src/app/components/valoracion/valoracion.component.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-item>\n  <ion-label>\n    <span *ngIf=\"total > 0; else noValoraciones\" style=\"display: flex; flex-direction: row;\">\n      <span class=\"calificacion\"></span> <p style=\"margin-right: 1vh;\">{{valoracion}}</p>\n    </span>\n    <span *ngIf=\"total > 0;\">\n      <p style=\"margin-top: 1vh;\">{{total}} valoraciones</p>\n    </span>\n    <ng-template #noValoraciones>\n      <p style=\"color: var(--ion-color-danger)\">Este usuario no tiene valoraciones aún</p>\n    </ng-template>\n  </ion-label>\n</ion-item>";

/***/ }),

/***/ 6981:
/*!**********************************************************************!*\
  !*** ./src/app/pages/perfil-otros/perfil-otros.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" default-href=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"body-page\">\n    <!-- Imagen del Usuario -->\n    <img *ngIf=\"usuarioAMostrar.foto != ''; else doesntHaveFoto\" src=\"{{usuarioAMostrar.foto}}\">\n    <ng-template #doesntHaveFoto>\n      <img src=\"./../../../assets/hellokitty.png\">\n    </ng-template>\n    <span class=\"nombreUsuario\">{{usuarioAMostrar.nombre}}</span>\n    <!-- Reputación -->\n    <section style=\"margin-top: 1.5vh; text-align: center;\">\n      <span style=\"font-size: 2.5vh; font-weight: 600; border-bottom: 1px solid;\">Reputación</span>\n      <reputacion [valoracion]=\"valoracion[0]\" [total]=\"valoracion[1]\"></reputacion>\n    </section>\n    <!-- Información del Usuario -->\n    <section style=\"margin-top: 2vh; display: flex; flex-direction: column; align-items: center; justify-self: center;\">\n      <span style=\"font-size: 2.5vh; font-weight: 600;\">Información del Usuario</span>\n      <div class=\"informacion-usuario\">\n        <div>\n          <span class=\"info-user-titulo\">Nombres:</span> <span>{{usuarioAMostrar.nombre}}</span>\n        </div>\n        <div>\n          <span class=\"info-user-titulo\">Rut:</span> <span>{{usuarioAMostrar.rut}}</span>\n        </div>\n        <div>\n          <span class=\"info-user-titulo\">Número:</span>\n          <span *ngIf=\"usuarioAMostrar.numero != null; else doesntHaveNumero\">\n            {{usuarioAMostrar.numero}}\n          </span>\n          <ng-template #doesntHaveNumero>\n            <span>No ha asignado un número</span>\n          </ng-template>\n        </div>\n        <span style=\"font-weight: 600; border-bottom: 1px solid; margin: 1.5vh 0vh 0.5vh 0vh;\">Información del Vehículo</span>\n        <div *ngIf=\"usuarioAMostrar.patente != null\">\n          <span class=\"info-user-titulo\">Patente:</span> <span>{{usuarioAMostrar.patente}}</span>\n        </div>\n        <!-- Agregar información del Conductor / Patente -->\n      </div>\n    </section>\n    <!-- Reportar Usuario -->\n    <ion-button id=\"open-modal\" expand=\"block\" fill=\"clear\" shape=\"round\" class=\"reportar-usuario\">\n      <ion-icon name=\"alert-circle\" style=\"margin-right: 1vh;\"></ion-icon> Reportar Usuario\n    </ion-button>\n    <!-- Modal -->\n    <ion-modal trigger=\"open-modal\" name=\"modal\" id=\"modal\">\n      <ng-template>\n        <ion-header>\n          <ion-toolbar>\n            <ion-buttons slot=\"start\">\n              <ion-button (click)=\"closeModal()\" style=\"color: red;\">Cancelar</ion-button>\n            </ion-buttons>\n            <ion-title>Reportar</ion-title>\n          </ion-toolbar>\n        </ion-header>\n        <ion-content class=\"ion-padding\">\n          <div class=\"form-content\">\n            <!-- Cambiar Jenniffer Coñuel por el nombre del usuario -->\n            <span style=\"font-size: 2.75vh; font-weight: 600;\">Reportar a Jenniffer Coñuel</span>\n            <span style=\"font-style: italic; text-align: center; word-break: break-word; margin-top: 2vh; margin-bottom: 2vh;\">\n              Recuerda que reportar de manera falsa o con malas intenciones es motivo de sanción.\n            </span>\n            <form name=\"reportform\" #reportform=\"ngForm\" (ngSubmit)=\"onSubmit(reportform)\">\n              <ion-item style=\"margin-top: 2vh;\">\n                <ion-label position=\"stacked\">Motivo del Reporte</ion-label>\n                <ion-select required name=\"motivo\" #motivo [(ngModel)]=\"reporte.motivo\" placeholder=\"Selecciona un Motivo\">\n                  <ion-select-option value=\"1\">Mal uso de la App</ion-select-option>\n                  <ion-select-option value=\"2\">Anuncio Fraudulento</ion-select-option>\n                  <ion-select-option value=\"3\">Mala conducta</ion-select-option>\n                  <ion-select-option value=\"4\">No es un conductor</ion-select-option>\n                  <ion-select-option value=\"5\">No pertenece a DuocUC</ion-select-option>\n                </ion-select>\n              </ion-item>\n              <ion-item style=\"margin-top: 6vh;\">\n                <ion-label position=\"stacked\">Descripción</ion-label>\n                <ion-textarea required name=\"descripcion\" placeholder=\"¿Qué hizo el usuario?\" #descripcion [(ngModel)]=\"reporte.descripcion\"></ion-textarea>\n              </ion-item>\n              <ion-button [disabled]=\"reportform.invalid\" type=\"submit\" expand=\"block\" fill=\"clear\" shape=\"round\" style=\"margin-top: 2.5vh; color: red;\">\n                Reportar\n              </ion-button>\n            </form>\n          </div>\n        </ion-content>\n      </ng-template>\n    </ion-modal>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_perfil-otros_perfil-otros_module_ts.js.map