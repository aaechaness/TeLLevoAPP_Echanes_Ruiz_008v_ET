import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desarrolladores',
  templateUrl: './desarrolladores.page.html',
  styleUrls: ['./desarrolladores.page.scss'],
})
export class DesarrolladoresPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
