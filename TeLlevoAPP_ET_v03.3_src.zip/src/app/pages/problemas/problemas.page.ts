import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-problemas',
  templateUrl: './problemas.page.html',
  styleUrls: ['./problemas.page.scss'],
})
export class ProblemasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
