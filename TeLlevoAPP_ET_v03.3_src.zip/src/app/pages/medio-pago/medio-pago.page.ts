import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medio-pago',
  templateUrl: './medio-pago.page.html',
  styleUrls: ['./medio-pago.page.scss'],
})
export class MedioPagoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
