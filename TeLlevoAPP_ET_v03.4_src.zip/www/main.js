(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _guards_session_guard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guards/session.guard */ 2025);




const routes = [
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_swiper_angular_fesm2015_swiper_angular_mjs"), __webpack_require__.e("src_app_pages_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/home/home.module */ 7994)).then(m => m.HomePageModule),
        canActivate: [_guards_session_guard__WEBPACK_IMPORTED_MODULE_0__.SessionGuard]
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/login/login.module */ 1053)).then(m => m.LoginPageModule)
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'register',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_register_register_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/register/register.module */ 207)).then(m => m.RegisterPageModule)
    },
    {
        path: 'perfil',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_perfil-usuario_perfil-usuario_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/perfil-usuario/perfil-usuario.module */ 1712)).then(m => m.PerfilUsuarioPageModule)
    },
    {
        path: 'recuperar-contrasena',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_recuperar-contrasena_recuperar-contrasena_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/recuperar-contrasena/recuperar-contrasena.module */ 7546)).then(m => m.RecuperarContrasenaPageModule)
    },
    {
        path: 'perfil-otros',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_perfil-otros_perfil-otros_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/perfil-otros/perfil-otros.module */ 8336)).then(m => m.PerfilOtrosPageModule)
    },
    {
        path: 'programar-viaje',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_swiper_angular_fesm2015_swiper_angular_mjs"), __webpack_require__.e("src_app_pages_programar-viaje_programar-viaje_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./pages/programar-viaje/programar-viaje.module */ 4095)).then(m => m.ProgramarViajePageModule)
    },
    {
        path: 'viajes',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_viajes_viajes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/viajes/viajes.module */ 8879)).then(m => m.ViajesPageModule)
    },
    {
        path: 'tus-viajes',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_tus-viajes_tus-viajes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/tus-viajes/tus-viajes.module */ 1948)).then(m => m.TusViajesPageModule)
    },
    {
        path: 'viaje',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_viaje_viaje_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/viaje/viaje.module */ 9809)).then(m => m.ViajePageModule)
    },
    {
        path: 'historial-viajes',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_historial-viajes_historial-viajes_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/historial-viajes/historial-viajes.module */ 7562)).then(m => m.HistorialViajesPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services/auth.service */ 7556);
/* harmony import */ var _services_reportes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/reportes.service */ 9216);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/storage.service */ 1188);
/* harmony import */ var _services_valoracion_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services/valoracion.service */ 2493);
/* harmony import */ var _services_viajes_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./services/viajes.service */ 1418);










let AppComponent = class AppComponent {
  constructor(_storage, _auth, _viajes, _report, _valoracion) {
    this._storage = _storage;
    this._auth = _auth;
    this._viajes = _viajes;
    this._report = _report;
    this._valoracion = _valoracion;
  }

  ngOnInit() {
    // If using a custom driver:
    //await this.storage.defineDriver(MyCustomDriver)
    //await this._storage.create();
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this._storage.init();
      yield _this._auth.loadData();
      yield _this._viajes.init(); //await this._report.init();
      //await this._valoracion.init();
    })();
  }

};

AppComponent.ctorParameters = () => [{
  type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService
}, {
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: _services_viajes_service__WEBPACK_IMPORTED_MODULE_7__.ViajesService
}, {
  type: _services_reportes_service__WEBPACK_IMPORTED_MODULE_4__.ReportesService
}, {
  type: _services_valoracion_service__WEBPACK_IMPORTED_MODULE_6__.ValoracionService
}];

AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-root',
  template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], AppComponent);


/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 287);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage-angular */ 516);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 898);









let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__.IonicStorageModule.forRoot({
                name: 'tellevoapp',
            }),
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
        ],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicRouteStrategy }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 4774:
/*!*****************************************!*\
  !*** ./src/app/enums/agendar-status.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgendarStatus": () => (/* binding */ AgendarStatus)
/* harmony export */ });
var AgendarStatus;
(function (AgendarStatus) {
    AgendarStatus[AgendarStatus["NOT_ENOUGH_SPACE"] = 0] = "NOT_ENOUGH_SPACE";
    AgendarStatus[AgendarStatus["ALREADY_TAKEN"] = 1] = "ALREADY_TAKEN";
    AgendarStatus[AgendarStatus["DONE"] = 2] = "DONE";
})(AgendarStatus || (AgendarStatus = {}));


/***/ }),

/***/ 2384:
/*!**************************************!*\
  !*** ./src/app/enums/login-state.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginState": () => (/* binding */ LoginState)
/* harmony export */ });
var LoginState;
(function (LoginState) {
    LoginState[LoginState["BAD_CREDENTIALS"] = 0] = "BAD_CREDENTIALS";
    LoginState[LoginState["USER_NOT_FOUND"] = 1] = "USER_NOT_FOUND";
    LoginState[LoginState["LOGGED_IN"] = 2] = "LOGGED_IN"; // Usuario logueado
})(LoginState || (LoginState = {}));


/***/ }),

/***/ 9394:
/*!******************************************!*\
  !*** ./src/app/enums/register-status.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterStatus": () => (/* binding */ RegisterStatus)
/* harmony export */ });
var RegisterStatus;
(function (RegisterStatus) {
    RegisterStatus[RegisterStatus["SUCCESSFUL"] = 0] = "SUCCESSFUL";
    RegisterStatus[RegisterStatus["ALREADY_REGISTERED"] = 1] = "ALREADY_REGISTERED";
    RegisterStatus[RegisterStatus["RUT_ALREADY_EXISTS"] = 2] = "RUT_ALREADY_EXISTS";
})(RegisterStatus || (RegisterStatus = {}));


/***/ }),

/***/ 1335:
/*!***************************************!*\
  !*** ./src/app/enums/viaje-status.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajeStatus": () => (/* binding */ ViajeStatus)
/* harmony export */ });
var ViajeStatus;
(function (ViajeStatus) {
    ViajeStatus["CANCELED"] = "Cancelado";
    ViajeStatus["PENDING"] = "Pendiente";
    ViajeStatus["COMPLETED"] = "Completado";
})(ViajeStatus || (ViajeStatus = {}));


/***/ }),

/***/ 2025:
/*!*****************************************!*\
  !*** ./src/app/guards/session.guard.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SessionGuard": () => (/* binding */ SessionGuard)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/auth.service */ 7556);





let SessionGuard = class SessionGuard {
  constructor(_auth, _router) {
    this._auth = _auth;
    this._router = _router;
  }

  hasSession() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let session = yield _this._auth.getSession();

      if (session != null) {
        return true;
      } else {
        _this._router.navigate(['/login']);
      }

      return false;
    })();
  }

  canActivate(route, state) {
    return this.hasSession();
  }

};

SessionGuard.ctorParameters = () => [{
  type: _services_auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router
}];

SessionGuard = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)({
  providedIn: 'root'
})], SessionGuard);


/***/ }),

/***/ 7556:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _encrypter_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./encrypter.service */ 653);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _enums_login_state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../enums/login-state */ 2384);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 898);
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./db.service */ 3773);
/* harmony import */ var _enums_register_status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../enums/register-status */ 9394);











let AuthService = class AuthService {
  constructor(_storage, _encrypt, _router, _toastCtrl, _alertCtrl, _http, _db) {
    this._storage = _storage;
    this._encrypt = _encrypt;
    this._router = _router;
    this._toastCtrl = _toastCtrl;
    this._alertCtrl = _alertCtrl;
    this._http = _http;
    this._db = _db;
  } // ! No eliminar aún; hay que cargar datos offline con LocalStorage :p

  /**
   @deprecated
   */


  _loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.session = yield _this._storage.getData('session');
      _this.userData = yield _this._storage.getData('usuarios');

      if (_this.userData === undefined || _this.userData === null) {
        _this.userData = yield _this._storage.addData('usuarios', {
          users: new Map()
        });
      }

      return _this.userData;
    })();
  }

  loadData() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Obtengo a los usuarios como una lista y luego la mapeo para que tenga sentido el interface.
      yield _this2.refreshUsers();
      const sessionID = yield _this2._storage.getData('session');

      if (sessionID != null) {
        _this2.session.user = _this2.userData.users.get(sessionID['correo']);
      }
    })();
  }

  refreshUsers() {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const usuarios = yield _this3._db.get('Usuarios');
      _this3.userData = {
        users: new Map(usuarios.map(user => [user['correo'], user]))
      };
    })();
  }

  getUser(email) {
    return this.userData.users.get(email);
  }

  getUsers() {
    return this.userData.users;
  }

  getSession() {
    var _this4 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this4.session == null) {
        _this4.session = yield _this4._storage.getData('session');
      }

      const user = {
        correo: _this4.session['correo'],
        rut: _this4.session['rut'],
        nombre: _this4.session['nombre'],
        contrasena: _this4.session['contrasena'],
        patente: _this4.session['patente'],
        foto: _this4.session['foto'],
        viaje: _this4.session['viaje'],
        numero: _this4.session['numero']
      };
      return user;
    })();
  }

  logout() {
    var _this5 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5._storage.removeData('session', 0);

      _this5._router.navigate(['/login']);

      const toast = yield _this5._toastCtrl.create({
        message: '¡Hasta pronto!',
        duration: 2000,
        icon: 'exit-outline'
      });
      yield toast.present();
      location.reload();
    })();
  }

  login(credentials) {
    var _this6 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this6._alertCtrl.create({
        header: '¡Error!',
        buttons: ['OK'],
        mode: 'ios',
        cssClass: 'datoserroneos'
      });

      if (_this6.userData.users.has(credentials['correo'])) {
        let user = _this6.userData.users.get(credentials['correo']);

        const encryptedPwd = _this6._encrypt.localEncrypt(credentials['contrasena']);

        if (user.contrasena === encryptedPwd) {
          _this6.session = yield _this6._storage.addData('session', user);
          let toast = yield _this6._toastCtrl.create({
            message: '¡Bienvenido de vuelta!',
            duration: 2000,
            icon: 'enter-outline'
          });
          yield toast.present();

          _this6._router.navigate(['/home']);

          return _enums_login_state__WEBPACK_IMPORTED_MODULE_3__.LoginState.LOGGED_IN;
        } else {
          alert.subHeader = 'Usuario y/o contraseña incorrectos';
          alert.message = 'Los datos que ha ingresado son incorrectos. Por favor, intente nuevamente.';
          yield alert.present();
          return _enums_login_state__WEBPACK_IMPORTED_MODULE_3__.LoginState.BAD_CREDENTIALS;
        }
      } else {
        alert.subHeader = 'Usuario no encontrado';
        alert.message = 'El correo electrónico que ha ingresado no está registrado. Por favor, intente nuevamente.';
        yield alert.present();
        return _enums_login_state__WEBPACK_IMPORTED_MODULE_3__.LoginState.USER_NOT_FOUND;
      }
    })();
  }

  registerUser(credentials) {
    var _this7 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let user = {
        correo: credentials['correo'] + credentials['extension'],
        rut: credentials['rut'],
        nombre: credentials['nombre'],
        contrasena: '',
        patente: credentials['patente'] || '',
        foto: '',
        viaje: null,
        numero: null
      };

      if (!_this7.userData.users.has(user.correo)) {
        if (!_this7.rutDoesExists(user.rut)) {
          const encryptedPwd = _this7._encrypt.localEncrypt(credentials['contrasena']);

          user.contrasena = encryptedPwd;
          yield _this7._storage.addData('session', user);

          _this7._db.insertOne('Usuarios', user);

          yield _this7.refreshUsers();

          _this7._router.navigate(['/home']);

          return _enums_register_status__WEBPACK_IMPORTED_MODULE_5__.RegisterStatus.SUCCESSFUL;
        }

        return _enums_register_status__WEBPACK_IMPORTED_MODULE_5__.RegisterStatus.RUT_ALREADY_EXISTS;
      }

      return _enums_register_status__WEBPACK_IMPORTED_MODULE_5__.RegisterStatus.ALREADY_REGISTERED;
    })();
  }
  /**
    @deprecated
    */


  _updateUser(user) {
    var _this8 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this8.userData.users.set(user.correo, user);

      yield _this8._storage.addData('usuarios', _this8.userData);
      yield _this8._storage.addData('session', user);
    })();
  }
  /**
    @param { Usuario } user Usuario a actualizar
    */


  updateUser(user) {
    var _this9 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this9._db.updateOne('usuarios', ['correo=' + user.correo], user);

      yield _this9._storage.addData('session', user);
      yield _this9.refreshUsers();
    })();
  }
  /**
    @deprecated
    */


  _changePassword(user, password) {
    var _this10 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this10._encrypt.encrypt(password).subscribe( /*#__PURE__*/function () {
        var _ref = (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (data) {
          user.contrasena = data['Digest'];

          _this10.userData.users.set(user.correo, user);

          yield _this10._storage.addData('usuarios', _this10.userData);
          yield _this10._storage.addData('session', user);
        });

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }
  /**
    @param { Usuario } user Usuario a actualizar
    @param { string } password Nueva contraseña
    */


  changePassword(user, password) {
    var _this11 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const encryptedPwd = _this11._encrypt.localEncrypt(password);

      user.contrasena = encryptedPwd;

      _this11._db.updateOne('Usuarios', ['correo=' + user.correo], user);

      yield _this11.refreshUsers();
    })();
  }

  userDoesExists(email) {
    return this.userData.users.has(email);
  }

  rutDoesExists(rut) {
    for (let usuario of this.userData.users.keys()) {
      if (this.userData.users.get(usuario)['rut'] == rut) {
        return true;
      }
    }

    return false;
  }

  verifyMail(email, code, username) {
    var _this12 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let url = 'http://localhost:3000/send-mail';
      return _this12._http.post(url, {
        type: 'verify',
        to: email,
        code: code,
        name: username
      }).subscribe(d => {
        console.log('Data: ' + d);
      });
    })();
  }

  recoverPassword(email, code, username) {
    var _this13 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let url = 'http://localhost:3000/send-mail';
      return _this13._http.post(url, {
        type: 'recover',
        to: email,
        code: code,
        name: username
      });
    })();
  }

  verifyPhone(phone, code) {
    var _this14 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let url = 'http://localhost:3000/send-sms';
      return _this14._http.post(url, {
        type: 'verify',
        phone: phone,
        code: code
      }).subscribe(d => {
        console.log('Data: ' + d);
      });
    })();
  }

};

AuthService.ctorParameters = () => [{
  type: _storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService
}, {
  type: _encrypter_service__WEBPACK_IMPORTED_MODULE_1__.EncrypterService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController
}, {
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClient
}, {
  type: _db_service__WEBPACK_IMPORTED_MODULE_4__.DbService
}];

AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable)({
  providedIn: 'root'
})], AuthService);


/***/ }),

/***/ 3773:
/*!****************************************!*\
  !*** ./src/app/services/db.service.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DbService": () => (/* binding */ DbService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 898);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);




let DbService = class DbService {
  constructor(_http) {
    this._http = _http; // private _url = 'http://localhost:3000/';
    //? Subir repositorio de la API a Github y hacer deploy en Railway.app. Para volverla una API pública.

    this._url = 'https://tellevoappapi-production.up.railway.app/';
  }
  /**
   * @param { String } collection Nombre de la colección de MongoDB
   * @param { Object | null } query? Lista de parámetros para el objeto a buscar.
   * @returns { Promise<Object> } Lista de Objetos encontrados.
   * @examples
   *  get('Usuarios', { rut: '12345678-9' });
   *  get('Usuarios');
   */


  get(collection, query) {
    let url = this._url + collection;

    if (query != undefined) {
      url += '?';
      query.forEach(q => {
        url += q + '&';
      });
    }

    if (url.endsWith('&')) url = url.replace('&', '');
    return this._http.get(url).toPromise();
  }
  /**
   * @param collection: Nombre de la colección de MongoDB
   * @param data: Objeto a insertar.
   * @returns { Promise<Object> } Objeto insertado.
   * @example insertOne('Usuarios', { rut: '12345678-9', nombre: 'Jenniffer' })
   */


  insertOne(collection, data, autoIncrement) {
    const url = this._url + collection;
    const body = {
      objectToInsert: data,
      autoIncrement: autoIncrement
    };
    return this._http.post(url, body).toPromise();
  }
  /**
   * @param collection: Nombre de la colección de MongoDB
   * @param data: Lista de objetos a insertar.
   * @returns { Observable<Object> } Lista de objetos insertados.
   * @example insertMany('Usuarios', [ { nombre: 'Fabian' }, { nombre: 'Rodrigo' }, { nombre: 'Jano' } ])
   */


  insertMany(collection, data) {
    const url = this._url + collection;
    const body = {
      objectToInsert: data,
      autoIncrement: false
    };
    return this._http.post(url, data);
  }
  /**
   * @param collection Nombre de la colección de MongoDB.
   * @param query Objeto a actualizar.
   * @param data Objeto a insertar.
   * @example updateOne('Usuarios', 'rut=20.919.721-9', { rut: '21.619.555-8', nombre: 'Aaron' })
   */


  updateOne(collection, query, data) {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let url = _this._url + collection;

      if (query != undefined) {
        url += '?';
        query.forEach(q => {
          url += q + '&';
        });
      }

      if (url.endsWith('&')) url = url.replace('&', '');
      return yield _this._http.put(url, data).toPromise();
    })();
  }
  /**
   * @param collection: Nombre de la colección de MongoDB
   * @param query: Objetos a actualizar.
   * @param data: Objeto a insertar.
   * @example updateOne('Usuarios', 'viaje=5', { viaje: 5 })
   */


  updateMany(collection, query, data) {
    let url = this._url + collection + '?' + query;
    return this._http.put(url, data).subscribe(resx => {
      return resx;
    });
    ;
  }
  /*
  @param collection: Nombre de la colección de MongoDB
  @param query: Objeto a eliminar.
  * Ejemplo: deleteOne('Usuarios', 'rut=20.919.721-9')
  */


  deleteOne(collection, query) {
    let url = this._url + collection;

    if (query != undefined) {
      url += '?';
      query.forEach(q => {
        url += q + '&';
      });
    }

    if (url.endsWith('&')) url = url.replace('&', '');
    return this._http.delete(url);
  }
  /*
  @param collection: Nombre de la colección de MongoDB
  @param query: Objetos a eliminar.
  * Ejemplo: deleteOne('Usuarios', ['rut=20.919.721-9', 'nombre=Ariel'])
  */


  deleteMany(collection, query) {
    let url = this._url + collection;

    if (query != undefined) {
      url += '?';
      query.forEach(q => {
        url += q + '&';
      });
    }

    if (url.endsWith('&')) url = url.replace('&', '');
    return this._http.delete(url);
  }

};

DbService.ctorParameters = () => [{
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
}];

DbService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], DbService);


/***/ }),

/***/ 653:
/*!***********************************************!*\
  !*** ./src/app/services/encrypter.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EncrypterService": () => (/* binding */ EncrypterService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 898);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);



let EncrypterService = class EncrypterService {
    constructor(_http) {
        this._http = _http;
    }
    /**
     * @param { String } data: Objeto a encriptar.
     * @returns { Observable } Objeto encriptado.
     * @deprecated Use localEncrypt instead.
     */
    encrypt(data) {
        return this._http.get('https://api.hashify.net/hash/sha256/hex?value=' + data);
    }
    /**
     * @param { String } data: String a encriptar.
     * @returns { String } String encriptado.
     */
    localEncrypt(data) {
        const splittedData = data.split('');
        let newString = '';
        for (const char of splittedData) {
            const newChar = char.charCodeAt(0);
            newString += newChar * 127 + ' ';
        }
        if (newString.endsWith(' ')) {
            newString = newString.slice(0, -1);
        }
        return newString;
    }
    /**
     * @param { String } data: Objeto a desencriptar.
     * @return { String } Objeto desencriptado.
     */
    localDencrypt(data) {
        const splittedData = data.split(' ');
        let newString = '';
        for (const char of splittedData) {
            const newChar = String.fromCharCode(parseInt(char, 10) / 127);
            newString += newChar;
        }
        return newString;
    }
};
EncrypterService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient }
];
EncrypterService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], EncrypterService);



/***/ }),

/***/ 9216:
/*!**********************************************!*\
  !*** ./src/app/services/reportes.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ReportesService": () => (/* binding */ ReportesService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);




let ReportesService = class ReportesService {
  constructor(_storage) {
    this._storage = _storage;
    this.reportes = {
      lastId: 0,
      reportes: []
    };
  }

  init() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.reportes = yield _this._storage.getData('reportes');

      if (_this.reportes === null) {
        _this.reportes = yield _this._storage.addData('reportes', {
          lastId: 0,
          reportes: []
        });
      }

      return _this.reportes;
    })();
  }

  reportUser(usuario, reportado, reporte) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.reportes.lastId++;
      let nuevoReporte = {
        id: _this2.reportes.lastId,
        motivo: reporte.motivo,
        descripcion: reporte.descripcion,
        usuarioReportado: reportado.correo,
        usuario: usuario.correo,
        fecha: new Date().toISOString()
      };

      _this2.reportes.reportes.push(nuevoReporte);

      yield _this2._storage.addData('reportes', _this2.reportes);
    })();
  }

  getReportes(query) {
    if (query) {
      let reportes = [];

      for (let key in query) {
        reportes.push(this.reportes.reportes.find(reporte => reporte[key] != null));
      }

      return reportes;
    }

    return this.reportes.reportes;
  }

  getReporte(id) {
    return this.reportes.reportes.find(r => r.id === id);
  }

};

ReportesService.ctorParameters = () => [{
  type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService
}];

ReportesService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ReportesService);


/***/ }),

/***/ 1188:
/*!*********************************************!*\
  !*** ./src/app/services/storage.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StorageService": () => (/* binding */ StorageService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage-angular */ 4357);




let StorageService = class StorageService {
  constructor(_storage) {
    this._storage = _storage;
  }

  init(key = null, params = null) {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this._storage.create();

      if (key && params) {
        yield _this._storage.set(key, params);
      }
    })();
  }

  getData(key) {
    return this._storage.get(key);
  }

  addData(key, data) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      //const storedData = await this._storage.get(key) || [];
      return _this2._storage.set(key, data) || [];
    })();
  }

  removeData(key, index) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const storedData = yield _this3._storage.get(key);

      if (storedData.constructor.toString().toLowerCase().indexOf('array') > -1) {
        storedData.splice(index, 1);
        return _this3._storage.set(key, storedData);
      } else {
        yield _this3._storage.remove(key);
      }
    })();
  }

};

StorageService.ctorParameters = () => [{
  type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__.Storage
}];

StorageService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], StorageService);


/***/ }),

/***/ 2493:
/*!************************************************!*\
  !*** ./src/app/services/valoracion.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValoracionService": () => (/* binding */ ValoracionService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./db.service */ 3773);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _viajes_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./viajes.service */ 1418);






let ValoracionService = class ValoracionService {
  constructor(_storage, _viajes, _db) {
    this._storage = _storage;
    this._viajes = _viajes;
    this._db = _db;
    this.valoraciones = {
      valoraciones: new Map(),
      lastId: 0
    };
  }

  init() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const valoraciones = yield _this._db.get('valoracion');
      _this.valoraciones = {
        valoraciones: new Map(valoraciones.map(valoracion => [valoracion['id'], valoracion])),
        lastId: 0
      };
    })();
  }

  getValoracion(user) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let viajes = yield _this2._viajes.getFrom(user);
      viajes = viajes.map(x => x.id);
      let valoracion = 0;
      let total = 0;

      _this2.valoraciones.valoraciones.forEach(x => {
        if (viajes.includes(x.viaje)) {
          valoracion += x.valoracion;
          total++;
        }
      });

      let valoracionFinal = valoracion / total || 0;
      return [valoracionFinal, total];
    })();
  }

  getValoracionesFrom(id) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const valoraciones = yield _this3._db.get('Valoracion', ["viaje=" + id]);
      return valoraciones;
    })();
  }

  userDidRate(user, viaje) {
    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return false;
    })();
  }

  addValoracion(viaje, usuario, calificacion, comentario = '') {
    var _this4 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.valoraciones.lastId++;
      let valoracion = {
        id: _this4.valoraciones.lastId,
        viaje: viaje.id,
        usuario: usuario.correo,
        valoracion: calificacion,
        comentario: comentario
      };
      let added = yield _this4._db.insertOne('Valoracion', valoracion, true);
      yield _this4.init();
      return added != null;
    })();
  }

  deleteValoracion(id) {
    var _this5 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5._db.deleteOne('Valoracion', ["id=" + id]);
      yield _this5.init();
    })();
  }

};

ValoracionService.ctorParameters = () => [{
  type: _storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService
}, {
  type: _viajes_service__WEBPACK_IMPORTED_MODULE_3__.ViajesService
}, {
  type: _db_service__WEBPACK_IMPORTED_MODULE_1__.DbService
}];

ValoracionService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
  providedIn: 'root'
})], ValoracionService);


/***/ }),

/***/ 1418:
/*!********************************************!*\
  !*** ./src/app/services/viajes.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajesService": () => (/* binding */ ViajesService)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 1188);
/* harmony import */ var _enums_viaje_status__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../enums/viaje-status */ 1335);
/* harmony import */ var _enums_agendar_status__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../enums/agendar-status */ 4774);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./auth.service */ 7556);
/* harmony import */ var _db_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./db.service */ 3773);








let ViajesService = class ViajesService {
  constructor(_storage, _auth, _db) {
    this._storage = _storage;
    this._auth = _auth;
    this._db = _db;
    this.viajesData = {
      viajes: new Map(),
      lastId: 0
    };
  }

  init() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const viajes = yield _this._db.get('viajes');
      _this.viajesData = {
        viajes: new Map(viajes.map(viaje => [viaje['id'], viaje])),
        lastId: 0
      };
    })();
  }

  getFrom(user) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.init();
      let viajes = [];

      _this2.viajesData.viajes.forEach(viaje => {
        if (viaje.conductor === user.correo) {
          viajes.push(viaje);
        }
      });

      return viajes; //* Probar el return de abajo
      //? [...this.viajesData.viajes.values()].filter(viaje => viaje.conductor.correo == user.correo)
    })();
  }

  get() {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.init();
      return _this3.viajesData;
    })();
  }

  getViaje(id) {
    var _this4 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.init();
      return _this4.viajesData.viajes.get(id);
    })();
  }

  scheduleViaje(viaje) {
    var _this5 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let viajesUser = yield _this5.getFrom(viaje['conductor']);
      viajesUser = viajesUser.filter(x => x.fecha == viaje['fecha']);

      if (viajesUser.length < 1) {
        let newViaje = {
          id: -1,
          fecha: viaje['fecha'],
          destino: viaje['destino'],
          precio: viaje['precio'],
          capacidad: viaje['capacidad'],
          descripcion: viaje['descripcion'],
          conductor: viaje['conductor'],
          pasajeros: [],
          valoraciones: [],
          estatus: _enums_viaje_status__WEBPACK_IMPORTED_MODULE_2__.ViajeStatus.PENDING
        };
        let added = yield _this5._db.insertOne('Viajes', newViaje, true);
        yield _this5.init();
        return added != null;
      }

      return false;
    })();
  }

  cancelViaje(id, user) {
    var _this6 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this6.viajesData.viajes.has(id.toString())) {
        if (_this6.viajesData.viajes.get(id.toString()).conductor === user.correo) {
          //if (this.viajesData.viajes.get(id.toString()).pasajeros.length === 0) {
          if (_this6.viajesData.viajes.get(id.toString()).fecha.getTime() > new Date().getTime()) {
            let viajeACancelar = _this6.viajesData.viajes.get(id.toString());

            viajeACancelar.estatus = _enums_viaje_status__WEBPACK_IMPORTED_MODULE_2__.ViajeStatus.CANCELED;
            viajeACancelar.pasajeros.forEach( /*#__PURE__*/function () {
              var _ref = (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (pasajero) {
                let pasajeroObject = _this6._auth.getUser(pasajero);

                pasajeroObject.viaje = null;
                yield _this6._auth.updateUser(user);
              });

              return function (_x) {
                return _ref.apply(this, arguments);
              };
            }());
            yield _this6._db.updateOne('Viajes', ["id=" + viajeACancelar.id], viajeACancelar);
            yield _this6.init();
            return true;
          }
        }
      }

      return false;
    })();
  }

  editViaje(viaje, user) {
    var _this7 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (viaje.conductor === user.correo) {
        yield _this7._db.updateOne('Viajes', ["id=" + viaje.id], viaje);
        yield _this7.init();
        return true;
      }

      return false;
    })();
  }

  changeStatus(id, status) {
    var _this8 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this8.viajesData.viajes.has(id.toString())) {
        let viaje = _this8.viajesData.viajes.get(id.toString());

        viaje.estatus = status;
        yield _this8._db.updateOne('Viajes', ["id=" + viaje.id], viaje);

        _this8.init();
      }
    })();
  }

  getRide(viaje, user) {
    var _this9 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let viajeATomar = yield _this9.getViaje(viaje);

      if (viajeATomar.capacidad - viajeATomar.pasajeros.length > 0) {
        if (viajeATomar.pasajeros.filter(pasajero => pasajero === user.correo).length === 0) {
          viajeATomar.pasajeros.push(user.correo);
          yield _this9.syncDataToLocal(user);
          yield _this9._db.updateOne('Viajes', ["id=" + viajeATomar.id], viajeATomar);
          user.viaje = viaje;
          yield _this9._auth.updateUser(user);
          yield _this9.init();
          return _enums_agendar_status__WEBPACK_IMPORTED_MODULE_3__.AgendarStatus.DONE;
        } else {
          return _enums_agendar_status__WEBPACK_IMPORTED_MODULE_3__.AgendarStatus.ALREADY_TAKEN;
        }
      }

      return _enums_agendar_status__WEBPACK_IMPORTED_MODULE_3__.AgendarStatus.NOT_ENOUGH_SPACE;
    })();
  }

  cancelRide(id, user) {
    var _this10 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this10.viajesData.viajes.has(id)) {
        let viaje = _this10.viajesData.viajes.get(id);

        if (viaje.pasajeros.filter(pasajero => pasajero === user.correo).length > 0) {
          let viaje = _this10.viajesData.viajes.get(id);

          viaje.pasajeros = viaje.pasajeros.filter(pasajero => pasajero !== user.correo);
          yield _this10._db.updateOne('Viajes', ["id=" + viaje.id], viaje);
          user.viaje = null;
          yield _this10._auth.updateUser(user);
          yield _this10.init();
          return true;
        }
      }

      return false;
    })();
  } //? Local data


  syncDataToLocal(user) {
    var _this11 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if ((yield _this11._storage.getData('viajes')) == null) {
        _this11._storage.init('viajes', {
          viajesAgendados: new Map(),
          viajesProgramados: new Map()
        });
      }

      const viajes = [..._this11.viajesData.viajes.values()].filter(viaje => viaje.pasajeros.includes(user.correo));
      const viajesMap = new Map(viajes.map(viaje => [viaje.id, viaje])); // Viajes agendados

      const viajesProgramados = [..._this11.viajesData.viajes.values()].filter(viaje => viaje.conductor === user.correo);
      const viajesProgramadosMap = new Map(viajesProgramados.map(viaje => [viaje.id, viaje]));
      yield _this11._storage.addData('viajes', {
        viajesAgendados: viajesMap,
        viajesProgramados: viajesProgramadosMap
      });
    })();
  }

  translateDate(date) {
    let dia = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'][date.getDay()];
    let mes = ['En', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'][date.getMonth()];
    let diaNum = date.getDate();
    let horas = date.getHours() > 9 ? date.getHours() : '0' + date.getHours();
    let minutos = date.getMinutes() > 9 ? date.getMinutes() : '0' + date.getMinutes();
    return `${dia} ${diaNum} de ${mes}. ${horas}:${minutos}`;
  }

};

ViajesService.ctorParameters = () => [{
  type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService
}, {
  type: _auth_service__WEBPACK_IMPORTED_MODULE_4__.AuthService
}, {
  type: _db_service__WEBPACK_IMPORTED_MODULE_5__.DbService
}];

ViajesService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
  providedIn: 'root'
})], ViajesService);


/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 3062);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		3750,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		733,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		985,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		3899,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		5121,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		2960,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		5473,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		7951,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		9787,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		7464,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		9569,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		5119,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		799,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		6519,
		"default-node_modules_ionic_core_dist_esm_parse-71f28cd7_js-node_modules_ionic_core_dist_esm_t-0c999b",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		8918,
		"default-node_modules_ionic_core_dist_esm_parse-71f28cd7_js-node_modules_ionic_core_dist_esm_t-0c999b",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		4028,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		8107,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		2178,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		123,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		8706,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		2099,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		4868,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		4377,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		5678,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		6735,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		2322,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		7754,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		7686,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8555,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		568,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		6231,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		5772,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		4977,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		2886,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		4990,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		3810,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		2446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		7619,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		8393,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		6281,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		5932,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		7970,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		298,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		1006,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		4783,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		2749,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5404,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		9043,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map