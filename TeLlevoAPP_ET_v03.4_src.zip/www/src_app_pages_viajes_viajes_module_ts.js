"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_viajes_viajes_module_ts"],{

/***/ 2635:
/*!*******************************************************!*\
  !*** ./src/app/pages/viajes/viajes-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajesPageRoutingModule": () => (/* binding */ ViajesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _viajes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./viajes.page */ 6330);




const routes = [
    {
        path: '',
        component: _viajes_page__WEBPACK_IMPORTED_MODULE_0__.ViajesPage
    }
];
let ViajesPageRoutingModule = class ViajesPageRoutingModule {
};
ViajesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ViajesPageRoutingModule);



/***/ }),

/***/ 8879:
/*!***********************************************!*\
  !*** ./src/app/pages/viajes/viajes.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajesPageModule": () => (/* binding */ ViajesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./viajes-routing.module */ 2635);
/* harmony import */ var _viajes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./viajes.page */ 6330);







let ViajesPageModule = class ViajesPageModule {
};
ViajesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__.ViajesPageRoutingModule
        ],
        declarations: [_viajes_page__WEBPACK_IMPORTED_MODULE_1__.ViajesPage]
    })
], ViajesPageModule);



/***/ }),

/***/ 6330:
/*!*********************************************!*\
  !*** ./src/app/pages/viajes/viajes.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ViajesPage": () => (/* binding */ ViajesPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./viajes.page.html?ngResource */ 5972);
/* harmony import */ var _viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./viajes.page.scss?ngResource */ 5855);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../enums/agendar-status */ 4774);










let ViajesPage = class ViajesPage {
  constructor(_router, _auth, _viajes, _toastCtrl) {
    this._router = _router;
    this._auth = _auth;
    this._viajes = _viajes;
    this._toastCtrl = _toastCtrl;
    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.viajes = [];
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.usuario = yield _this._auth.getSession();
      _this.viajes = [];
      let viajesArr = yield _this._viajes.get();
      viajesArr.viajes.forEach(viaje => {
        if (viaje.conductor != _this.usuario.correo) {
          let viajeRaw = viaje;
          viajeRaw['translatedDate'] = _this._viajes.translateDate(new Date(viajeRaw.fecha.toString()));
          viajeRaw['details'] = false;
          viajeRaw['isTaken'] = viaje.pasajeros.filter(pasajero => pasajero === _this.usuario.correo).length > 0;
          let pasajerosObject = [];
          viajeRaw.pasajeros.forEach(pasajero => {
            pasajerosObject.push(_this._auth.getUser(pasajero));
          });
          viajeRaw['conductorObject'] = _this._auth.getUser(viajeRaw.conductor);
          viajeRaw['pasajerosObject'] = pasajerosObject;

          _this.viajes.push(viajeRaw);
        }
      });
    })();
  }

  isAvalaible(index) {
    if (this.viajes[index]['isTaken']) {
      return false;
    }

    if (this.viajes[index]['capacidad'] === this.viajes[index]['pasajeros'].length) {
      return false;
    }

    return true;
  }

  showViajeDetails(index, event) {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let src = event.srcElement;

      while (src.tagName != 'ION-ITEM') {
        src = src.parentElement;
      }

      if (_this2.viajes[index].details) {
        _this2.viajes[index].details = false;
        src.setAttribute("detail-icon", "chevron-forward-outline");
        /*
        ! Esto no va
        const animation = createAnimation()
          .addElement(event.srcElement)
          .duration(1000)
          .fromTo('', '1', '0.5');
        //console.log()
        */
      } else {
        _this2.viajes[index].details = true;
        src.setAttribute("detail-icon", "chevron-down-outline");
      }
    })();
  }

  agendar(id, e) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let isDone = yield _this3._viajes.getRide(id, _this3.usuario);

      if (isDone === _enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__.AgendarStatus.DONE) {
        _this3.showViajeDetails(id, e);

        let toast = yield _this3._toastCtrl.create({
          message: 'Viaje Agendado!',
          duration: 1500,
          icon: 'checkmark-circle-outline'
        });
        yield toast.present();
        yield _this3.loadData();
      } else if (isDone === _enums_agendar_status__WEBPACK_IMPORTED_MODULE_5__.AgendarStatus.ALREADY_TAKEN) {
        let toast = yield _this3._toastCtrl.create({
          message: 'Ya agendaste este Viaje',
          duration: 3000,
          icon: 'alert-circle-outline',
          buttons: [{
            text: 'Cancelar',
            role: 'cancelarViaje',
            handler: () => {
              console.log('Viaje cancelado');
            }
          }, {
            text: 'Descartar',
            role: 'cancel',
            handler: () => {
              console.log('Chau');
            }
          }]
        });
        yield toast.present();
      } else {
        let toast = yield _this3._toastCtrl.create({
          message: 'No fue posible agendar este viaje',
          duration: 1500,
          icon: 'sad-outline'
        });
        yield toast.present();
      }
    })();
  }

  goToProfile(user) {
    this._router.navigate(['/perfil-otros'], {
      queryParams: {
        correo: user.correo
      }
    });
  }

  seeViajeDetails(id) {
    this._router.navigate(['/viaje'], {
      queryParams: {
        id: id
      }
    });
  }

};

ViajesPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController
}];

ViajesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-viajes',
  template: _viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ViajesPage);


/***/ }),

/***/ 5855:
/*!**********************************************************!*\
  !*** ./src/app/pages/viajes/viajes.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".content-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.resumen-lista-viajes {\n  display: flex;\n  flex-direction: column;\n  margin-top: 2vh;\n  width: 90%;\n}\n\n.resumen-lista-viajes-viaje {\n  display: flex;\n  flex-direction: column;\n  margin: 2vh 0vh;\n  border: 0.25px solid;\n  padding: 1vh;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZpYWplcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQUNKOztBQUVFO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLG9CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFDSiIsImZpbGUiOiJ2aWFqZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbnQtYm9keSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLnJlc3VtZW4tbGlzdGEtdmlhamVzIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgbWFyZ2luLXRvcDogMnZoO1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICB9XHJcbiAgXHJcbiAgLnJlc3VtZW4tbGlzdGEtdmlhamVzLXZpYWplIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgbWFyZ2luOiAydmggMHZoO1xyXG4gICAgYm9yZGVyOiAwLjI1cHggc29saWQ7XHJcbiAgICBwYWRkaW5nOiAxdmg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICB9Il19 */";

/***/ }),

/***/ 5972:
/*!**********************************************************!*\
  !*** ./src/app/pages/viajes/viajes.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" routerLink=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>\n      TeLlevoApp\n    </ion-title>\n  </ion-toolbar>\n  <ion-toolbar>\n    <ion-searchbar animated=\"true\" placeholder=\"Busca el destino\"></ion-searchbar>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"content-body\">\n    <section *ngIf=\"usuario.patente != ''\" style=\"margin: 1.5vh 0vh;\">\n      <ion-item>\n        <div style=\"display: flex; flex-direction: column; align-items: center; margin: 0vh 4vh;\">\n          <ion-icon name=\"list-outline\" style=\"width: 4vh; height: 4vh;\"></ion-icon>\n          <ion-label>Todos los Viajes</ion-label>\n        </div>\n        <div style=\"display: flex; flex-direction: column; align-items: center; margin: 0vh 4vh;\"\n          (click)=\"_router.navigate(['tus-viajes'])\">\n          <ion-icon name=\"car-outline\" style=\"width: 4vh; height: 4vh;\"></ion-icon>\n          <ion-label>Tus Viajes</ion-label>\n        </div>\n      </ion-item>\n    </section>\n    <section class=\"resumen-lista-viajes\" *ngIf=\"viajes.length > 0; else notEnoughtViajes\">\n      <!--? ngFor -->\n      <div style=\"border: 1px solid; border-radius: 1vh; margin: 0.75vh 0vh;\" *ngFor=\"let viaje of viajes; index as x\">\n        <ion-item detail=\"true\" (click)=\"showViajeDetails(x, $event)\" class=\"viaje-{{x}}\">\n          <ion-label>\n            <p style=\"margin-bottom: 0.5vh;\">\n              {{viaje.translatedDate}}\n            </p>\n            <span style=\"margin: 0.25vh 0vh;\">{{viaje.destino}}</span>\n            <p style=\"margin-top: 0.5vh;\">\n              {{viaje.capacidad - viaje.pasajeros.length}} Disponible(s) | ${{viaje.precio}} de Tarifa\n            </p>\n          </ion-label>\n        </ion-item>\n        <ion-list class=\"viaje-{{x}}-details\" *ngIf=\"viajes[x].details == true\">\n          <!--? Conductor -->\n          <ion-list-header>\n            <ion-label>Conductor</ion-label>\n          </ion-list-header>\n          <ion-item (click)=\"goToProfile(viaje.conductorObject)\">\n            <ion-avatar slot=\"start\">\n              <img *ngIf=\"viaje.conductorObject.foto != ''; else conductorDoesntHaveFoto\"\n                src=\"{{viaje.conductorObject.foto}}\" />\n              <ng-template #conductorDoesntHaveFoto>\n                <img src=\"./../../../assets/hellokitty.png\" />\n              </ng-template>\n            </ion-avatar>\n            <ion-label>{{viaje.conductorObject.nombre}}</ion-label>\n          </ion-item>\n          <ion-item>\n            <ion-label>\n              <span style=\"display: flex; align-content: center; justify-content: space-around; align-items: center; flex-direction: row; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n                <p (click)=\"agendar(viaje.id, $event)\" style=\"color: var(--ion-color-success)\" *ngIf=\"isAvalaible(x); else notEnoughSpace\">\n                  Reservar\n                <p>\n                <ng-template #notEnoughSpace>\n                  <p style=\"color: var(--ion-color-danger)\">Reservar<p>\n                </ng-template>\n                <p (click)=\"seeViajeDetails(viaje.id)\" style=\"color: var(--ion-color-primary)\">Detalles del Viaje</p>\n              </span>\n            </ion-label>\n          </ion-item>\n        </ion-list>\n        <!--\n        <ion-item class=\"viaje-{{x}}-details\" *ngIf=\"viajes[x].details == true\">\n          <ion-label style=\"display: flex; flex-direction: column;\">\n            <span>Conductor: {{viaje.conductor.nombre}}</span>\n            <span style=\"margin-top: 0.25vh; border-bottom: 1px solid; max-width: 10vh;\">Pasajeros:</span>\n            <p style=\"margin-top: 1vh; display: flex; flex-direction: column;\"\n              *ngIf=\"viaje.pasajeros.length > 0; else noPassengers\">\n              <span *ngFor=\"let pasajero of viaje.pasajerosObject\">\n                - {{pasajero.nombre}}\n              </span>\n            </p>\n            <ng-template #noPassengers>\n              <p style=\"color: var(--ion-color-danger); margin-top: 0.25vh;\">\n                No hay pasajeros aún\n              </p>\n            </ng-template>\n            <span style=\"display: flex; align-content: center; justify-content: space-around; align-items: center; flex-direction: row; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n              <p (click)=\"agendar(viaje.id, $event)\" style=\"color: var(--ion-color-success)\" *ngIf=\"isAvalaible(x); else notEnoughSpace\">\n                Reservar\n              <p>\n              <ng-template #notEnoughSpace>\n                <p style=\"color: var(--ion-color-danger)\">Reservar<p>\n              </ng-template>\n              <p (click)=\"seeViajeDetails(viaje.id)\" style=\"color: var(--ion-color-primary)\">Detalles del Viaje</p>\n            </span>\n          </ion-label>\n        </ion-item>\n        -->\n      </div>\n      <!--\n      <ion-item-sliding style=\"border: 1px solid; border-radius: 1vh; margin: 0.75vh 0vh;\" *ngFor=\"let viaje of viajes; index as x\">\n        <ion-item detail=\"true\" (click)=\"showViajeDetails(x, $event)\" class=\"viaje-{{x}}\">\n          <ion-label>\n            <p style=\"margin-bottom: 0.5vh;\">\n              {{viaje.translatedDate}}\n            </p>\n            <span style=\"margin: 0.25vh 0vh;\">{{viaje.destino}}</span>\n            <p style=\"margin-top: 0.5vh;\">\n              {{viaje.capacidad - viaje.pasajeros.length}} Disponible(s) | ${{viaje.precio}} de Tarifa\n            </p>\n          </ion-label>\n        </ion-item>\n        <ion-item-options>\n          <ion-item-option color=\"success\" style=\"color: black;\" (click)=\"agendar(viaje.id)\">\n            <ion-icon slot=\"top\" size=\"large\" name=\"push-outline\"></ion-icon>\n            Agendar\n          </ion-item-option>\n        </ion-item-options>\n        <ion-item *ngIf=\"viajes[x].details == true\">\n          <ion-label style=\"display: flex; flex-direction: column;\">\n            <span>Conductor: {{viaje.conductor.nombre}}</span>\n            <span style=\"margin-top: 0.25vh; border-bottom: 1px solid; max-width: 10vh;\">Pasajeros:</span>\n            <p style=\"margin-top: 1vh; display: flex; flex-direction: column;\" *ngIf=\"viaje.pasajeros.length > 0; else noPassengers\">\n              <span *ngFor=\"let pasajero of viaje.pasajeros\">\n                - {{pasajero.nombre}}\n              </span>\n            </p>\n            <ng-template #noPassengers>\n              <p style=\"color: red; margin-top: 0.25vh;\">\n                No hay pasajeros aún\n              </p>\n            </ng-template>\n            <span (click)=\"agendar(viaje.id)\" *ngIf=\"isAvalaible(x); else notEnoughSpace\" style=\"margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid; text-align: center;\">\n              <p style=\"color: #2dd36f\">Reservar<p>\n            </span>\n            <ng-template #notEnoughSpace>\n              <span (click)=\"agendar(viaje.id)\" style=\"margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid; text-align: center;\">\n                <p style=\"color: #eb445a\">Reservar<p>\n              </span>\n            </ng-template>\n          </ion-label>\n        </ion-item>\n      </ion-item-sliding>\n      -->\n      <!--? Fin ngFor -->\n    </section>\n    <ng-template #notEnoughtViajes>\n      <div\n        style=\"margin: 2.5vh 0vh; display: flex; flex-direction: column; align-content: center; justify-content: center; align-items: center;\">\n        <span style=\"color: red; text-align: center;\">No hay viajes programados :(</span>\n        <a style=\"text-align: center; margin: 1vh 0vh;\">\n          <ion-icon name=\"refresh-outline\"></ion-icon> Recargar\n        </a>\n      </div>\n    </ng-template>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_viajes_viajes_module_ts.js.map