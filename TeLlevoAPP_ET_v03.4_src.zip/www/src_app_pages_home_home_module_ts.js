"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_home_module_ts"],{

/***/ 6610:
/*!***************************************************!*\
  !*** ./src/app/pages/home/home-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 678);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 7994:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 678);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 6610);
/* harmony import */ var swiper_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! swiper/angular */ 4044);








let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule,
            swiper_angular__WEBPACK_IMPORTED_MODULE_7__.SwiperModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 678:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.html?ngResource */ 8380);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 2260);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! swiper */ 3371);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 5992);
/* harmony import */ var src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/enums/agendar-status */ 4774);












swiper__WEBPACK_IMPORTED_MODULE_5__["default"].use([swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination, _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicSlides]);
let HomePage = class HomePage {
  constructor(_router, _menu, _auth, _viajes, _toastCtrl) {
    this._router = _router;
    this._menu = _menu;
    this._auth = _auth;
    this._viajes = _viajes;
    this._toastCtrl = _toastCtrl;
    this.usuario = {
      correo: '',
      nombre: '',
      contrasena: '',
      rut: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.lastViajes = [];
    this.viajeActual = {
      id: null,
      fecha: null,
      destino: '',
      precio: null,
      capacidad: null,
      descripcion: '',
      conductor: null,
      pasajeros: [],
      valoraciones: [],
      estatus: null
    };
    this.viajesUsuario = [];
  }

  ngOnInit() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.loadData();

      _this.cerrarMenu();
    })();
  }

  loadData() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Eliminar datos anteriores
      _this2.lastViajes = [];
      _this2.viajesUsuario = []; // Recargar datos

      yield _this2._auth.refreshUsers();
      _this2.usuario = yield _this2._auth.getSession(); // Cargar viaje que tomó el Usuario

      if (_this2.usuario.viaje != null) {
        _this2.viajeActual = yield _this2._viajes.getViaje(_this2.usuario.viaje);
        _this2.viajeActual['translatedDate'] = _this2._viajes.translateDate(new Date(_this2.viajeActual.fecha.toString()));
      } // Cargar viajes que el Usuario creó


      if (_this2.usuario.patente != '') {
        let viajesDelUsuario = yield _this2._viajes.getFrom(_this2.usuario);
        viajesDelUsuario = viajesDelUsuario.sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime());

        for (let viaje of viajesDelUsuario) {
          if (_this2.viajesUsuario.length < 5) {
            let viajeAPushear = viaje;
            viajeAPushear['translatedDate'] = _this2._viajes.translateDate(new Date(viaje.fecha.toString()));

            _this2.viajesUsuario.push(viajeAPushear);
          } else {
            break;
          }
        }
      }

      let viajes = yield _this2._viajes.get();
      let viajesArray = Array.from(viajes.viajes.values()).filter(viaje => viaje.conductor != _this2.usuario.correo && viaje.pasajeros.indexOf(_this2.usuario.correo) == -1);

      if (viajesArray.length > 0) {
        let ultimoViaje; // Como no se puede romper un forEach, utilizo una excepción para salir del ciclo.

        const BreakException = {};

        try {
          viajesArray.forEach((viaje, index) => {
            if (index < 5 && ultimoViaje != index) {
              let viajeAMostrar = viaje;
              viajeAMostrar['translatedDate'] = _this2._viajes.translateDate(new Date(viaje.fecha.toString()));

              _this2.lastViajes.push(viajeAMostrar);

              ultimoViaje = index;
            } else {
              throw BreakException;
            }
          });
        } catch (e) {
          if (e !== BreakException) throw e;
        }
      }

      yield _this2._viajes.syncDataToLocal(_this2.usuario);
    })();
  }

  agendarIfTaken(id) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this3._router.navigate(['/viaje'], {
        queryParams: {
          id: id
        }
      });
    })();
  }

  agendar(id) {
    var _this4 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let isDone = yield _this4._viajes.getRide(id, _this4.usuario);

      if (isDone === src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_6__.AgendarStatus.DONE) {
        let toast = yield _this4._toastCtrl.create({
          message: 'Viaje Agendado!',
          duration: 1500,
          icon: 'checkmark-circle-outline'
        });
        yield toast.present();

        _this4._router.navigate(['/home']);
      } else if (isDone === src_app_enums_agendar_status__WEBPACK_IMPORTED_MODULE_6__.AgendarStatus.ALREADY_TAKEN) {
        let toast = yield _this4._toastCtrl.create({
          message: 'Ya agendaste este Viaje',
          duration: 3000,
          icon: 'alert-circle-outline',
          buttons: [{
            text: 'Cancelar',
            role: 'cancelarViaje',
            handler: () => {
              console.log('Viaje cancelado');
            }
          }, {
            text: 'Descartar',
            role: 'cancel',
            handler: () => {
              console.log('Chau');
            }
          }]
        });
        yield toast.present();
      } else {
        let toast = yield _this4._toastCtrl.create({
          message: 'No fue posible agendar este viaje',
          duration: 1500,
          icon: 'sad-outline'
        });
        yield toast.present();
      }
    })();
  }

  seeViajeDetails(id) {
    this._router.navigate(['/viaje'], {
      queryParams: {
        id: id
      }
    });
  }

  cancelarViaje(id) {
    var _this5 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let cancelado = yield _this5._viajes.cancelRide(id, _this5.usuario);

      if (cancelado) {
        const toast = yield _this5._toastCtrl.create({
          message: 'Has cancelado tu reserva',
          duration: 1500,
          position: 'bottom',
          icon: "close-circle-outline"
        });
        yield toast.present();

        _this5._router.navigate(['/home']);
      } else {
        const toast = yield _this5._toastCtrl.create({
          message: 'No se pudo cancelar tu reserva',
          duration: 1500,
          position: 'bottom',
          icon: "alert-circle-outline"
        });
        yield toast.present();
      }
    })();
  }

  logout() {
    this.cerrarMenu();

    this._auth.logout();
  }

  changePage(page) {
    var _this6 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this6.cerrarMenu();

      page == '/login' ? yield _this6._auth.logout() : _this6._router.navigate([page]);
    })();
  }

  verMenu() {
    this._menu.open('menu');
  }

  cerrarMenu() {
    this._menu.close('menu');
  }

};

HomePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.MenuController
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ToastController
}];

HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-home',
  template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], HomePage);


/***/ }),

/***/ 2260:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.content-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.title {\n  font-weight: 600;\n  font-size: 3vh;\n  max-width: 80%;\n  word-break: break-word;\n  white-space: pre-line;\n  text-align: center;\n}\n\n.buscas-viaje {\n  font-weight: 600;\n  font-size: 3vh;\n  word-break: break-word;\n  white-space: pre-line;\n  text-align: center;\n}\n\n.viaje-title {\n  font-weight: 600;\n  font-size: 2.2vh;\n  border-bottom: 1px solid;\n  margin-bottom: 1.5vh;\n  padding-bottom: 0.5vh;\n  text-align: center;\n}\n\n.viaje-content-title {\n  border-bottom: 1px solid;\n  margin-right: 0.5vh;\n}\n\n.resumen-lista-viajes {\n  display: flex;\n  flex-direction: column;\n  margin-top: 2vh;\n}\n\n.resumen-lista-viajes-viaje {\n  display: flex;\n  flex-direction: column;\n  margin: 2vh 0vh;\n  border: 0.25px solid;\n  padding: 1vh;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esd0JBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUFDRjs7QUFFQTtFQUNFLHdCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQ0YiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuXG4jY29udGFpbmVyIHN0cm9uZyB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgbGluZS1oZWlnaHQ6IDI2cHg7XG59XG5cbiNjb250YWluZXIgcCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDIycHg7XG4gIGNvbG9yOiAjOGM4YzhjO1xuICBtYXJnaW46IDA7XG59XG5cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn1cblxuLmNvbnRlbnQtYm9keSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4udGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDN2aDtcbiAgbWF4LXdpZHRoOiA4MCU7XG4gIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG4gIHdoaXRlLXNwYWNlOiBwcmUtbGluZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uYnVzY2FzLXZpYWplIHtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1zaXplOiAzdmg7XG4gIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG4gIHdoaXRlLXNwYWNlOiBwcmUtbGluZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4udmlhamUtdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDIuMnZoO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQ7XG4gIG1hcmdpbi1ib3R0b206IDEuNXZoO1xuICBwYWRkaW5nLWJvdHRvbTogMC41dmg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnZpYWplLWNvbnRlbnQtdGl0bGUge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQ7XG4gIG1hcmdpbi1yaWdodDogMC41dmg7XG59XG5cbi5yZXN1bWVuLWxpc3RhLXZpYWplcyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIG1hcmdpbi10b3A6IDJ2aDtcbn1cblxuLnJlc3VtZW4tbGlzdGEtdmlhamVzLXZpYWplIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgbWFyZ2luOiAydmggMHZoO1xuICBib3JkZXI6IDAuMjVweCBzb2xpZDtcbiAgcGFkZGluZzogMXZoO1xuICB3aWR0aDogMTAwJTtcbn0iXX0= */";

/***/ }),

/***/ 8380:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<!-- Header -->\n<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-icon slot=\"start\" name=\"menu\" size=\"large\" class=\"ion-padding\" (click)=\"verMenu()\"></ion-icon>\n    <ion-title>\n      TeLlevoApp\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n<!-- Menú -->\n<ion-menu side=\"start\" menuId=\"menu\" contentId=\"main\">\n  <ion-header>\n    <ion-toolbar color=\"dark\">\n      <ion-title>Menu</ion-title>\n      <ion-icon slot=\"end\" name=\"close\" size=\"large\" class=\"ion-padding\" (click)=\"cerrarMenu()\"></ion-icon>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n    <ion-list>\n      <ion-item detail (click)=\"changePage('/perfil')\">\n        <ion-icon slot=\"start\" name=\"person-circle-outline\"></ion-icon>\n        Perfil\n      </ion-item>\n      <ion-item detail (click)=\"changePage('/viajes')\">\n        <ion-icon slot=\"start\" name=\"book-outline\"></ion-icon>\n        Viajes\n      </ion-item>\n      <ion-item detail (click)=\"changePage('/historial-viajes')\">\n        <ion-icon slot=\"start\" name=\"reader-outline\"></ion-icon>\n        Historial de Viajes\n      </ion-item>\n      <ion-item detail (click)=\"changePage('/programar-viaje')\" *ngIf=\"usuario.patente != ''\">\n        <ion-icon slot=\"start\" name=\"car-outline\"></ion-icon>\n        Programar Viaje\n      </ion-item>\n      <ion-item detail (click)=\"logout()\">\n        <ion-icon slot=\"start\" name=\"log-out-outline\"></ion-icon>\n        Salir\n      </ion-item>\n    </ion-list>\n  </ion-content>\n</ion-menu>\n<ion-router-outlet id=\"main\"></ion-router-outlet>\n<!-- Fin Menú -->\n<!-- Main -->\n<ion-content [fullscreen]=\"true\" class=\"ion-padding\">\n  <div class=\"content-body\">\n    <span class=\"title\">Bienvenido/a, {{usuario.nombre}}</span>\n  </div>\n  <!--? Tiene un Viaje Reservado -->\n  <div *ngIf=\"usuario.viaje != null; else doesntHaveViaje\" class=\"content-body\">\n    <span\n      style=\"font-size: 2.4vh; font-weight: 600; border-bottom: 1px solid; margin-bottom: 1vh; padding-bottom: 0.5vh;\">\n      Viaje Agendado\n    </span>\n    <ion-item style=\"max-width: 32vh;\">\n      <ion-label>\n        <p style=\"margin-bottom: 0.5vh;\">\n          {{viajeActual.translatedDate}}\n        </p>\n        <span style=\"text-overflow: ellipsis; overflow: hidden; white-space: nowrap;\">{{viajeActual.destino}}</span>\n        <p *ngIf=\"viajeActual.capacidad - viajeActual.pasajeros.length > 0; else noDisponible\"\n          style=\"margin-top: 0.5vh;\">\n          {{viajeActual.capacidad - viajeActual.pasajeros.length}} Disponible(s) | ${{viajeActual.precio}} de Tarifa\n        </p>\n        <ng-template #noDisponible>\n          <p style=\"margin-top: 0.5vh; color: var(--ion-color-danger);\">\n            No disponible | ${{viajeActual.precio}} de Tarifa\n          </p>\n        </ng-template>\n        <span\n          style=\"display: flex; align-content: center; justify-content: center; align-items: center; flex-direction: row; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n          <p (click)=\"seeViajeDetails(viajeActual.id)\" style=\"color: var(--ion-color-primary); margin: 0vh 2.5vh;\">\n            Detalles</p>\n          <p (click)=\"cancelarViaje(viajeActual.id)\" style=\"color: var(--ion-color-danger); margin: 0vh 2.5vh;\">\n            Cancelar\n          <p>\n        </span>\n      </ion-label>\n    </ion-item>\n  </div>\n  <div *ngIf=\"usuario.viaje != null;\"\n    style=\"border-top: 1px solid; margin-top: 4vh; padding-top: 4vh; text-align: center;\">\n    <span style=\"font-size: 2.5vh; font-weight: 600; border-bottom: 1px solid; padding-bottom: 0.5vh;\">¿Deseas agendar\n      otro?</span>\n  </div>\n  <swiper *ngIf=\"usuario.viaje != null;\" [pagination]=\"true\" style=\"margin-top: 2vh;\">\n    <ng-template swiperSlide *ngFor=\"let viaje of lastViajes\">\n      <ion-item style=\"margin-bottom: 6vh; max-width: 32vh;\">\n        <ion-label style=\"display: flex; flex-direction: column;\">\n          <p style=\"margin-bottom: 0.5vh;\">{{viaje.translatedDate}}</p>\n          <span style=\"text-overflow: ellipsis; overflow: hidden; white-space: nowrap;\">{{viaje.destino}}</span>\n          <p *ngIf=\"viajeActual.capacidad - viajeActual.pasajeros.length > 0; else noDisponible1\" style=\"margin-top: 0.5vh;\">\n            {{viajeActual.capacidad - viajeActual.pasajeros.length}} Disponible(s) | ${{viajeActual.precio}} de Tarifa\n          </p>\n          <ng-template #noDisponible1>\n            <p style=\"margin-top: 0.5vh; color: var(--ion-color-danger);\">\n              No disponible | ${{viaje.precio}} de Tarifa\n            </p>\n          </ng-template>\n          <span style=\"display: flex; align-content: center; justify-content: center; align-items: center; flex-direction: row; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n            <p (click)=\"seeViajeDetails(viaje.id)\" style=\"color: var(--ion-color-primary); margin: 0vh 2.5vh;\">Detalles\n            </p>\n            <p (click)=\"seeViajeDetails(viaje.id)\" style=\"color: var(--ion-color-success); margin: 0vh 2.5vh;\">\n              Agendar\n            </p>\n          </span>\n        </ion-label>\n      </ion-item>\n    </ng-template>\n  </swiper>\n  <div *ngIf=\"usuario.viaje != null;\" style=\"text-align: center;\">\n    <span style=\"margin-right: 1vh;\">¿No encontraste tu destino?</span>\n    <a (click)=\"changePage('viajes')\">Ve la lista de Viajes</a>\n  </div>\n  <!--? Fin del Viaje Reservado -->\n  <!--? No tiene un Viaje Reservado -->\n  <ng-template #doesntHaveViaje>\n    <div class=\"content-body\">\n      <div style=\"margin-top: 2vh; display: flex; flex-direction: column;\">\n        <span class=\"buscas-viaje\">¿Buscas un Viaje?</span>\n        <span style=\"margin-top: 0.5vh; text-align: center;\">Explora los viajes disponibles</span>\n      </div>\n    </div>\n    <swiper *ngIf=\"lastViajes.length > 0; else notEnoughtViajes\" [pagination]=\"true\" style=\"margin-top: 2vh;\">\n      <ng-template swiperSlide *ngFor=\"let viaje of lastViajes\">\n        <ion-item style=\"margin-bottom: 6vh; max-width: 32vh;\">\n          <ion-label style=\"display: flex; flex-direction: column;\">\n            <p style=\"margin-bottom: 0.5vh;\">{{viaje.translatedDate}}</p>\n            <span style=\"text-overflow: ellipsis; overflow: hidden; white-space: nowrap;\">{{viaje.destino}}</span>\n            <p *ngIf=\"viaje.capacidad - viaje.pasajeros.length > 0; else noDisponible2\" style=\"margin-top: 0.5vh;\">\n              {{viaje.capacidad - viaje.pasajeros.length}} Disponible(s) | ${{viaje.precio}} de Tarifa\n            </p>\n            <ng-template #noDisponible2>\n              <p style=\"margin-top: 0.5vh; color: var(--ion-color-danger);\">\n                No disponible | ${{viaje.precio}} de Tarifa\n              </p>\n            </ng-template>\n            <span\n              style=\"display: flex; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n              <p (click)=\"agendar(viaje.id)\" style=\"color: var(--ion-color-success); margin: 0vh 2.5vh;\">\n                Agendar\n              </p>\n              <p (click)=\"seeViajeDetails(viaje.id)\"\n                style=\"color: var(--ion-color-primary); margin: 0vh 2.5vh; text-align: center;\">\n                Detalles\n              </p>\n            </span>\n          </ion-label>\n        </ion-item>\n      </ng-template>\n    </swiper>\n    <section *ngIf=\"lastViajes.length > 0;\" style=\"text-align: center;\">\n      <span style=\"margin-right: 1vh;\">¿No encontraste lo que buscabas?</span>\n      <a (click)=\"changePage('viajes')\">Ve la lista de Viajes</a>\n    </section>\n    <ng-template #notEnoughtViajes>\n      <div\n        style=\"margin: 2.5vh 0vh; display: flex; flex-direction: column; align-content: center; justify-content: center; align-items: center;\">\n        <span style=\"color: red; text-align: center;\">No hay viajes programados :(</span>\n        <a (click)=\"loadData()\" style=\"text-align: center; margin: 1vh 0vh;\">\n          <ion-icon name=\"refresh-outline\"></ion-icon> Recargar\n        </a>\n      </div>\n    </ng-template>\n  </ng-template>\n  <!--? Fin de no tiene un Viaje Reservado -->\n  <!--? Viajes del Usuario si es que es Conductor -->\n  <div *ngIf=\"usuario.patente != ''\" style=\"border-top: 1px solid; margin-top: 4vh;\" class=\"content-body\">\n    <span style=\"margin-top: 4vh;\" class=\"buscas-viaje\">Viajes Programados</span>\n    <p style=\"margin-top: 0.5vh; text-align: center;\">Tus últimos 5 viajes programados</p>\n  </div>\n  <swiper *ngIf=\"viajesUsuario.length > 0; else haventCreatedViajes\" [pagination]=\"true\" style=\"margin-top: 2vh;\">\n    <ng-template swiperSlide *ngFor=\"let viaje of viajesUsuario\">\n      <ion-item style=\"margin-bottom: 6vh; max-width: 32vh;\">\n        <ion-label style=\"display: flex; flex-direction: column;\">\n          <p style=\"margin-bottom: 0.5vh;\">{{viaje.translatedDate}}</p>\n          <span style=\"text-overflow: ellipsis; overflow: hidden; white-space: nowrap;\">{{viaje.destino}}</span>\n          <p *ngIf=\"viaje.capacidad - viaje.pasajeros.length > 0; else noDisponible3\" style=\"margin-top: 0.5vh;\">\n            {{viaje.capacidad - viaje.pasajeros.length}} Disponible(s) | ${{viaje.precio}} de Tarifa\n          </p>\n          <ng-template #noDisponible3>\n            <p style=\"margin-top: 0.5vh; color: var(--ion-color-danger);\">\n              No disponible | ${{viajeActual.precio}} de Tarifa\n            </p>\n          </ng-template>\n          <span\n            style=\"display: flex; justify-content: center; margin-top: 1vh; padding: 1.25vh 1vh; border-bottom: 1px solid; border-top: 1px solid;\">\n            <p (click)=\"seeViajeDetails(viaje.id)\"\n              style=\"color: var(--ion-color-primary); margin: 0vh 2.5vh; text-align: center;\">\n              Detalles\n            </p>\n          </span>\n        </ion-label>\n      </ion-item>\n    </ng-template>\n  </swiper>\n  <ng-template *ngIf=\"usuario.patente != ''\" #haventCreatedViajes>\n    <div\n      style=\"margin: 2.5vh 0vh; display: flex; flex-direction: column; align-content: center; justify-content: center; align-items: center;\">\n      <span style=\"color: red; text-align: center;\">Aún no has programado ningún viaje</span>\n      <ion-button (click)=\"changePage('programar-viaje')\" expand=\"block\" fill=\"clear\" shape=\"round\">\n        Programar Viaje\n      </ion-button>\n    </div>\n  </ng-template>\n  <!--? Fin de Viajes del Usuario -->\n  <!--? Footer -->\n  <div class=\"content-body\">\n    <footer\n      style=\"display: flex; flex-direction: column; align-items: center; justify-content: center; position: absolute; margin-left: auto; margin-right: auto; left: 0; right: 0; bottom: 2vh;\">\n      <span style=\"font-weight: 400; font-size: 2.5vh;\">TeLlevoApp</span>\n      <img src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/a/aa/Logo_DuocUC.svg/2560px-Logo_DuocUC.svg.png\"\n        style=\"width: 24vh;\">\n    </footer>\n  </div>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home_module_ts.js.map