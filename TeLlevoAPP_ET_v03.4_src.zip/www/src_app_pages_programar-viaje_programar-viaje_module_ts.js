"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_programar-viaje_programar-viaje_module_ts"],{

/***/ 2573:
/*!*************************************************************************!*\
  !*** ./src/app/pages/programar-viaje/programar-viaje-routing.module.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramarViajePageRoutingModule": () => (/* binding */ ProgramarViajePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _programar_viaje_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./programar-viaje.page */ 9752);




const routes = [
    {
        path: '',
        component: _programar_viaje_page__WEBPACK_IMPORTED_MODULE_0__.ProgramarViajePage
    }
];
let ProgramarViajePageRoutingModule = class ProgramarViajePageRoutingModule {
};
ProgramarViajePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProgramarViajePageRoutingModule);



/***/ }),

/***/ 4095:
/*!*****************************************************************!*\
  !*** ./src/app/pages/programar-viaje/programar-viaje.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramarViajePageModule": () => (/* binding */ ProgramarViajePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _programar_viaje_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./programar-viaje-routing.module */ 2573);
/* harmony import */ var _programar_viaje_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./programar-viaje.page */ 9752);
/* harmony import */ var swiper_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! swiper/angular */ 4044);








let ProgramarViajePageModule = class ProgramarViajePageModule {
};
ProgramarViajePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _programar_viaje_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProgramarViajePageRoutingModule,
            swiper_angular__WEBPACK_IMPORTED_MODULE_7__.SwiperModule
        ],
        declarations: [_programar_viaje_page__WEBPACK_IMPORTED_MODULE_1__.ProgramarViajePage]
    })
], ProgramarViajePageModule);



/***/ }),

/***/ 9752:
/*!***************************************************************!*\
  !*** ./src/app/pages/programar-viaje/programar-viaje.page.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramarViajePage": () => (/* binding */ ProgramarViajePage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _programar_viaje_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./programar-viaje.page.html?ngResource */ 4271);
/* harmony import */ var _programar_viaje_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./programar-viaje.page.scss?ngResource */ 3654);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! swiper */ 3371);










swiper__WEBPACK_IMPORTED_MODULE_5__["default"].use([swiper__WEBPACK_IMPORTED_MODULE_5__.Pagination]);
let ProgramarViajePage = class ProgramarViajePage {
  constructor(_toastCtrl, _auth, _viajes, _router) {
    this._toastCtrl = _toastCtrl;
    this._auth = _auth;
    this._viajes = _viajes;
    this._router = _router;
    this.usuario = {
      correo: '',
      contrasena: '',
      rut: '',
      nombre: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.viaje = {
      id: null,
      fecha: null,
      destino: '',
      precio: null,
      capacidad: null,
      descripcion: null,
      conductor: this.usuario.correo,
      pasajeros: [],
      valoraciones: [],
      estatus: null
    };
    this.hoy = new Date().toISOString();
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.usuario = yield _this._auth.getSession();
    })();
  }

  onSubmit() {
    var _this2 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this2.viaje.conductor = _this2.usuario.correo;
      _this2.viaje.fecha = new Date(_this2.fecha.value.toString());
      let wasScheduled = yield _this2._viajes.scheduleViaje(_this2.viaje);

      if (wasScheduled) {
        let buttons = [{
          text: 'Lista de Viajes',
          role: 'lista_de_viajes',
          handler: () => {
            _this2._router.navigate(['/tus-viajes']);
          }
        }];

        _this2.sendToast('¡Viaje programado! Puedes verlo en tu lista de Viajes', 'today-outline', buttons);

        _this2._router.navigate(['/home']);
      } else {
        _this2.sendToast('Ha ocurrido un error. Inténtalo de nuevo', 'alert-circle-outline');
      }
    })();
  }

  sendToast(msg, icon = undefined, buttons = undefined) {
    var _this3 = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this3._toastCtrl.create({
        message: msg,
        duration: 3000
      });
      if (icon != undefined) toast.icon = icon;
      if (buttons != undefined) toast.buttons = buttons;
      yield toast.present();
    })();
  }

};

ProgramarViajePage.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController
}, {
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router
}];

ProgramarViajePage.propDecorators = {
  fecha: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild,
    args: ['fecha']
  }]
};
ProgramarViajePage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-programar-viaje',
  template: _programar_viaje_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_programar_viaje_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProgramarViajePage);


/***/ }),

/***/ 3654:
/*!****************************************************************************!*\
  !*** ./src/app/pages/programar-viaje/programar-viaje.page.scss?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = ".content-body {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n\n.title {\n  margin-top: 2.5vh;\n  font-weight: 600;\n  font-size: 3.5vh;\n  max-width: 80%;\n  word-break: break-word;\n  white-space: pre-line;\n  text-align: center;\n}\n\n.subtitle {\n  margin-top: 2vh;\n  word-break: break-word;\n  max-width: 32vh;\n  text-align: center;\n}\n\n[ng-reflect-disabled=true] {\n  color: red;\n}\n\n[ng-reflect-disabled=false] {\n  color: lime;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2dyYW1hci12aWFqZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQ0o7O0FBRUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFFQTtFQUNJLFVBQUE7QUFDSjs7QUFFQTtFQUNJLFdBQUE7QUFDSiIsImZpbGUiOiJwcm9ncmFtYXItdmlhamUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbnQtYm9keSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi50aXRsZSB7XG4gICAgbWFyZ2luLXRvcDogMi41dmg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXNpemU6IDMuNXZoO1xuICAgIG1heC13aWR0aDogODAlO1xuICAgIHdvcmQtYnJlYWs6IGJyZWFrLXdvcmQ7XG4gICAgd2hpdGUtc3BhY2U6IHByZS1saW5lO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnN1YnRpdGxlIHtcbiAgICBtYXJnaW4tdG9wOiAydmg7XG4gICAgd29yZC1icmVhazogYnJlYWstd29yZDtcbiAgICBtYXgtd2lkdGg6IDMydmg7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG5bbmctcmVmbGVjdC1kaXNhYmxlZD10cnVlXSB7XG4gICAgY29sb3I6IHJlZDtcbn1cblxuW25nLXJlZmxlY3QtZGlzYWJsZWQ9ZmFsc2VdIHtcbiAgICBjb2xvcjogbGltZTtcbn0iXX0= */";

/***/ }),

/***/ 4271:
/*!****************************************************************************!*\
  !*** ./src/app/pages/programar-viaje/programar-viaje.page.html?ngResource ***!
  \****************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" default-href=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"content-body\">\n    <span class=\"title\">Programar un Viaje</span>\n    <span class=\"subtitle\">Por favor rellene los campos con los datos correspondientes</span>\n    <form #unviaje=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n      <ion-item style=\"margin: 2vh 0vh;\">\n        <ion-label position=\"stacked\">Ingresa el destino</ion-label>\n        <ion-input type=\"text\" placeholder=\"Los Copihues, Talcahuano\" name=\"destino\" [(ngModel)]=\"viaje.destino\"\n          mode=\"ios\" required></ion-input>\n      </ion-item>\n      <ion-item style=\"margin: 2vh 0vh;\">\n        <ion-label position=\"stacked\">Ingresa el precio</ion-label>\n        <ion-input type=\"number\" placeholder=\"2500\" name=\"precio\" [(ngModel)]=\"viaje.precio\" mode=\"ios\" required min=\"1000\">\n        </ion-input>\n      </ion-item>\n      <ion-item style=\"margin: 2vh 0vh;\">\n        <ion-label position=\"stacked\">Ingresa la capacidad</ion-label>\n        <ion-input type=\"number\" placeholder=\"4\" name=\"capacidad\" [(ngModel)]=\"viaje.capacidad\" mode=\"ios\" required max=10 min=1>\n        </ion-input>\n      </ion-item>\n      <ion-item style=\"margin: 2vh 0vh;\">\n        <ion-label position=\"stacked\">Selecciona una Fecha y Hora</ion-label>\n        <ion-datetime-button style=\"margin-top: 1vh;\" datetime=\"datetime\">\n          <span slot=\"time-label\">Hora</span>\n        </ion-datetime-button>\n        <ion-modal [keepContentsMounted]=\"true\">\n          <ng-template>\n            <ion-datetime id=\"datetime\" name=\"fecha\" #fecha locale=\"es-CL\" hourCycle=\"h23\"\n              min=\"{{hoy}}\"></ion-datetime>\n          </ng-template>\n        </ion-modal>\n      </ion-item>\n      <ion-item style=\"margin: 2vh 0vh;\">\n        <ion-label position=\"stacked\">Descripción (opcional)</ion-label>\n        <ion-textarea name=\"descripcion\" [(ngModel)]=\"viaje.descripcion\"\n          placeholder=\"Auto de marca ... y color ..., estacionado en ...\" mode=\"ios\"></ion-textarea>\n      </ion-item>\n      <ion-button [disabled]=\"unviaje.invalid\" type=\"submit\" expand=\"block\" fill=\"clear\" shape=\"round\">\n        Agregar\n      </ion-button>\n    </form>\n  </div>\n  <!--* Plantilla para listar Viajes\n            <ion-item-sliding>\n              <ion-item>\n                <ion-label>\n                  <p style=\"margin-bottom: 0.5vh;\">\n                    Martes 23 de Nov. 14:30\n                  </p>\n                  <span style=\"margin: 0.25vh 0vh;\">Los Copihues, Talcahuano</span>\n                  <p style=\"margin-top: 0.5vh;\">\n                    4 Disponibles | $1.500 de Tarifa\n                  </p>\n                </ion-label>\n              </ion-item>\n              <ion-item-options>\n                <ion-item-option color=\"danger\">\n                  <ion-icon slot=\"icon-only\" name=\"trash-outline\"></ion-icon>\n                </ion-item-option>\n              </ion-item-options>\n            </ion-item-sliding>\n            -->\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_programar-viaje_programar-viaje_module_ts.js.map