"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_historial-viajes_historial-viajes_module_ts"],{

/***/ 4537:
/*!***************************************************************************!*\
  !*** ./src/app/pages/historial-viajes/historial-viajes-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialViajesPageRoutingModule": () => (/* binding */ HistorialViajesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var _historial_viajes_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./historial-viajes.page */ 4908);




const routes = [
    {
        path: '',
        component: _historial_viajes_page__WEBPACK_IMPORTED_MODULE_0__.HistorialViajesPage
    }
];
let HistorialViajesPageRoutingModule = class HistorialViajesPageRoutingModule {
};
HistorialViajesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HistorialViajesPageRoutingModule);



/***/ }),

/***/ 7562:
/*!*******************************************************************!*\
  !*** ./src/app/pages/historial-viajes/historial-viajes.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialViajesPageModule": () => (/* binding */ HistorialViajesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 7073);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 8665);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 1864);
/* harmony import */ var _historial_viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./historial-viajes-routing.module */ 4537);
/* harmony import */ var _historial_viajes_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./historial-viajes.page */ 4908);







let HistorialViajesPageModule = class HistorialViajesPageModule {
};
HistorialViajesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _historial_viajes_routing_module__WEBPACK_IMPORTED_MODULE_0__.HistorialViajesPageRoutingModule
        ],
        declarations: [_historial_viajes_page__WEBPACK_IMPORTED_MODULE_1__.HistorialViajesPage]
    })
], HistorialViajesPageModule);



/***/ }),

/***/ 4908:
/*!*****************************************************************!*\
  !*** ./src/app/pages/historial-viajes/historial-viajes.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialViajesPage": () => (/* binding */ HistorialViajesPage)
/* harmony export */ });
/* harmony import */ var C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9369);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 3786);
/* harmony import */ var _historial_viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./historial-viajes.page.html?ngResource */ 5360);
/* harmony import */ var _historial_viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./historial-viajes.page.scss?ngResource */ 4928);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4565);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 8298);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 7556);
/* harmony import */ var src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/viajes.service */ 1418);








let HistorialViajesPage = class HistorialViajesPage {
  constructor(_auth, _viaje, _router) {
    this._auth = _auth;
    this._viaje = _viaje;
    this._router = _router;
    this.usuario = {
      correo: '',
      nombre: '',
      contrasena: '',
      rut: '',
      patente: '',
      foto: '',
      viaje: null,
      numero: null
    };
    this.viajes = [];
  }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    var _this = this;

    return (0,C_Ionic_Pruebas_TeLlevoApp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this.viajes = [];
      _this.usuario = yield _this._auth.getSession(); //? Obtengo los viajes del usuario

      let viajes = yield _this._viaje.get();
      viajes.viajes.forEach(viaje => {
        if (viaje.pasajeros.includes(_this.usuario.correo)) {
          let viajeToAdd = viaje;
          viajeToAdd['translatedDate'] = _this._viaje.translateDate(new Date(viaje.fecha));

          _this.viajes.push(viajeToAdd);
        }
      });
    })();
  }

  seeViajeDetails(id) {
    this._router.navigate(['/viaje'], {
      queryParams: {
        id: id
      }
    });
  }

};

HistorialViajesPage.ctorParameters = () => [{
  type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService
}, {
  type: src_app_services_viajes_service__WEBPACK_IMPORTED_MODULE_4__.ViajesService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}];

HistorialViajesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-historial-viajes',
  template: _historial_viajes_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_historial_viajes_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], HistorialViajesPage);


/***/ }),

/***/ 4928:
/*!******************************************************************************!*\
  !*** ./src/app/pages/historial-viajes/historial-viajes.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = ".content-body {\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n}\n\n.title {\n  font-weight: 600;\n  font-size: 3vh;\n  max-width: 80%;\n  word-break: break-word;\n  white-space: pre-line;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpc3RvcmlhbC12aWFqZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQUNKIiwiZmlsZSI6Imhpc3RvcmlhbC12aWFqZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRlbnQtYm9keSB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG5cbi50aXRsZSB7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBmb250LXNpemU6IDN2aDtcbiAgICBtYXgtd2lkdGg6IDgwJTtcbiAgICB3b3JkLWJyZWFrOiBicmVhay13b3JkO1xuICAgIHdoaXRlLXNwYWNlOiBwcmUtbGluZTtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59Il19 */";

/***/ }),

/***/ 5360:
/*!******************************************************************************!*\
  !*** ./src/app/pages/historial-viajes/historial-viajes.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "<!-- Header -->\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button mode=\"ios\" text=\"Volver\" default-href=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>TeLlevoApp</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div style=\"margin-top: 2vh;\" class=\"content-body\">\n    <span class=\"title\">Historial de Viajes</span>\n    <div>\n      <p style=\"text-align: center; max-width: 40vh;\">Historial de Viajes reservados</p>\n      <p style=\"text-align: center; max-width: 40vh;\">Los viajes que hayas reservado serán mostrados aquí.</p>\n    </div>\n  </div>\n  <!--? Listo los Viajes del Usuario -->\n  <ion-list style=\"display: flex; flex-direction: column; align-items: center;\" *ngIf=\"viajes.length > 0; else doesntHaveViajes\">\n    <ion-item style=\"margin: 1vh 0vh;\" lines=\"full\" *ngFor=\"let viaje of viajes\">\n      <ion-label>\n        <p style=\"margin-bottom: 0.5vh;\">\n          {{viaje.translatedDate}}\n        </p>\n        <span style=\"text-overflow: ellipsis; overflow: hidden; white-space: nowrap;\">{{viaje.destino}}</span>\n        <p style=\"margin-top: 0.5vh;\">\n          {{viaje.pasajeros.length}} Pasajero(s) | ${{viaje.precio}} de Tarifa\n        </p>\n        <!--? Estado del Viaje -->\n        <p *ngIf=\"viaje.estatus == 'Completado'\" style=\"color: var(--ion-color-success); font-size: 2vh; margin-bottom: 1vh; display: flex;\n                    align-items: center;\">\n          <ion-icon name=\"checkmark-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n        </p>\n        <p *ngIf=\"viaje.estatus == 'Pendiente'\" style=\"color: var(--ion-color-warning); font-size: 2vh;\n                    margin-bottom: 1vh; display: flex; align-items: center;\">\n          <ion-icon name=\"time-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n        </p>\n        <p *ngIf=\"viaje.estatus == 'Cancelado'\" style=\"color: var(--ion-color-danger); font-size: 2vh;\n                    margin-bottom: 1vh; display: flex; align-items: center;\">\n          <ion-icon name=\"close-circle-outline\" style=\"margin-right: 0.5vh;\"></ion-icon> {{viaje.estatus}}\n        </p>\n        <!--? Fin Estado del Viaje -->\n        <!--? Detalles -->\n        <a (click)=\"seeViajeDetails(viaje.id)\">Ver información completa</a>\n      </ion-label>\n    </ion-item>\n  </ion-list>\n  <ng-template #doesntHaveViajes>\n    <div style=\"margin-top: 2vh;\" class=\"content-body\">\n      <span style=\"color: var(--ion-color-danger);\">No tienes registro de viajes reservados</span>\n      <p>¿Por qué no intentas agendar uno?</p>\n    </div>\n  </ng-template>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_historial-viajes_historial-viajes_module_ts.js.map