import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router'

@Component({
  selector: 'app-info',
  templateUrl: './info.page.html',
  styleUrls: ['./info.page.scss'],
})
export class InfoPage implements OnInit {

  infoId;
  feriado;

  constructor(private http: HttpClient, private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.infoId = this.activatedRoute.snapshot.paramMap.get('id')
    this.http.get('https://api.roison.cl/feriados.json' + this.infoId)
    .subscribe(res => this.feriado = res);
  }
}
