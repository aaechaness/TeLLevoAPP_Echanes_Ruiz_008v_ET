export interface Usuarios {
    users: Map<string, {}>;
}

export interface Usuario {
    correo: string;
    contrasena: string;
    rut: string;
    nombre: string;
    patente: string;
    foto: string;
    viaje: number | null; // id del viaje actual
    numero: number | null;
}
