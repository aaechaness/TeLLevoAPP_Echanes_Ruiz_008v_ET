# TeLlevoApp
TeLlevoApp, Proyecto Semestral.

<h2>USUARIOS</h2>

Correo: admin@duocuc.cl<br>
Password: admin1<br>
Tipo: Administrador<br>
<br>
Correo: a.echanes@duocuc.cl<br>
Password: 123456<br>
"Conductor"<br>
<br>
Correo: jor.ruizp@duocuc.cl<br>
Password: 123456<br>
"Pasajero"<br>
<br>
<h3>Modulos:</h3>
<code>npm install --save @ionic/storage</code><br>
<code>npm install --save @ionic/storage-angular</code><br>
<br>
<br>
<code>npm install node-fetch@2.0</code><br>
<code>npm i swiper</code><br>
<br>
<code>ionic cap sync
<br>
<code>npm install -g json-server</code><br>